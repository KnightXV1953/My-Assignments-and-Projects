import os, json, uuid, time
from typing import Dict, Any, List, Tuple
from .llm_client import llm_complete
from .plan_execute import plan_execute


ALLOWED_ACTIONS = {
    "pickup_survivor",
    "drop_at_hospital",
    "extinguish_fire",
    "clear_rubble",
    "recharge",
}


def _format_system_prompt(strategy_name: str) -> str:
    return (
        "You are CrisisSim's planner. Follow rules strictly.\n"
        "- Output two messages per tick: first 'Thought: ...' then 'FINAL_JSON: { ... }'\n"
        "- FINAL_JSON must be STRICT JSON with schema {\"commands\":[...]} only.\n"
        "- Do not include comments or trailing text after FINAL_JSON.\n"
        f"- Strategy: {strategy_name}. Use appropriate reasoning.\n"
    )


def _format_user_prompt(context: Dict[str, Any], extra_instructions: str = "") -> str:
    return (
        "Context JSON (state):\n" + json.dumps(context, ensure_ascii=False) + "\n\n"
        "Tool spec:\n"
        "- You control heterogeneous agents on a grid. Ticks are discrete.\n"
        "- Valid command schema: {\"commands\":[{\"agent_id\":\"id\", \"type\":\"move|act\", ...}]}\n"
        "- If type=move: include 'to':[x,y] that is exactly one Manhattan step away and within bounds.\n"
        "- If type=act: include 'action_name' in {pickup_survivor, drop_at_hospital, extinguish_fire, clear_rubble, recharge}.\n"
        + ("\n" + extra_instructions if extra_instructions else "")
    )


def _extract_final_json(text: str) -> Tuple[dict, int, str]:
    """
    Return (obj, invalid_json, thought_text). invalid_json=1 if parse failed else 0.
    """
    thought = ""
    if text is None:
        return {"commands": []}, 1, thought
    try:
        # Split on FINAL_JSON:
        parts = text.split("FINAL_JSON:")
        if len(parts) == 2:
            thought_part = parts[0].strip()
            thought = thought_part.replace("Thought:", "").strip()
            payload = parts[1].strip()
        else:
            # No marker; try to parse entire text as JSON
            payload = text.strip()
        obj = json.loads(payload)
        if not isinstance(obj, dict) or "commands" not in obj:
            return {"commands": []}, 1, thought
        return obj, 0, thought
    except Exception:
        return {"commands": []}, 1, thought


def _validate_commands(obj: dict, grid_w: int, grid_h: int) -> Tuple[List[dict], int]:
    """Validate and filter commands. Returns (valid_cmds, num_repairs)."""
    cmds = obj.get("commands", []) if isinstance(obj, dict) else []
    valid: List[dict] = []
    repairs = 0
    for c in cmds:
        if not isinstance(c, dict):
            repairs += 1
            continue
        agent_id = str(c.get("agent_id", "")).strip()
        typ = c.get("type")
        if not agent_id or typ not in ("move", "act"):
            repairs += 1
            continue
        if typ == "move":
            to = c.get("to")
            if not (isinstance(to, list) and len(to) == 2 and all(isinstance(v, (int, float)) for v in to)):
                repairs += 1
                continue
            x, y = int(to[0]), int(to[1])
            if not (0 <= x < grid_w and 0 <= y < grid_h):
                repairs += 1
                continue
            # one-step Manhattan
            # Agent current pos unknown here; we trust LLM, environment enforces passability and step size
            valid.append({"agent_id": agent_id, "type": "move", "to": [x, y]})
        else:
            an = c.get("action_name")
            if not (isinstance(an, str) and an in ALLOWED_ACTIONS):
                repairs += 1
                continue
            valid.append({"agent_id": agent_id, "type": "act", "action_name": an})
    return valid, repairs


class PlanRunner:
    def __init__(self, strategy: str, run_dir: str):
        self.strategy = strategy
        self.run_dir = run_dir
        os.makedirs(self.run_dir, exist_ok=True)

    def _log(self, tick: int, lines: List[Dict[str, str]]):
        path = os.path.join(self.run_dir, f"tick={tick}.jsonl")
        with open(path, "a", encoding="utf-8") as f:
            for line in lines:
                f.write(json.dumps(line, ensure_ascii=False) + "\n")

    def _strategy_instructions(self, context: Dict[str, Any], scratchpad: str) -> str:
        if self.strategy == "react":
            return (
                "Use ReAct: think step-by-step using available actions and then output FINAL_JSON.\n"
                f"Scratchpad (last turns):\n{scratchpad}\n"
            )
        if self.strategy == "reflexion":
            from .reflexion import load_rules
            mem = load_rules()
            rules = "\n".join(mem.get("rules", [])[-5:])
            return (
                "Use Reflexion: critique past mistakes and apply learned rules before acting.\n"
                f"Rules:\n{rules}\n"
                f"Scratchpad:\n{scratchpad}\n"
            )
        if self.strategy == "plan_execute":
            return (
                "Use Plan-and-Execute: first outline a brief plan, then emit FINAL_JSON commands for this tick.\n"
                f"Scratchpad:\n{scratchpad}\n"
            )
        # default
        return f"Scratchpad:\n{scratchpad}\n"

    def plan_tick(self, tick: int, context: Dict[str, Any], scratchpad: str = "", max_retries: int = 2) -> Tuple[Dict[str, Any], Dict[str, int]]:
        tool_calls = 0
        invalid_json = 0
        replans = 0

        system = _format_system_prompt(self.strategy)
        extra = self._strategy_instructions(context, scratchpad)
        user = _format_user_prompt(context, extra)

        run_lines = [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ]

        # Initial call
        tool_calls += 1
        raw = llm_complete(system + "\n\n" + user)
        obj, inv, thought = _extract_final_json(raw)
        invalid_json += inv
        self._log(tick, run_lines + [
            {"role": "assistant", "content": f"Thought: {thought}"},
            {"role": "assistant", "content": "FINAL_JSON: " + (json.dumps(obj) if inv == 0 else "{}")},
        ])

        if inv:
            # Retry loop with error feedback
            for _ in range(max_retries):
                replans += 1
                tool_calls += 1
                fb = "Your last response was invalid JSON or schema. Return ONLY FINAL_JSON with valid commands."
                raw = llm_complete(system + "\n\n" + user + "\n\n" + fb)
                obj, inv2, thought2 = _extract_final_json(raw)
                invalid_json += inv2
                self._log(tick, [
                    {"role": "assistant", "content": f"Thought: {thought2}"},
                    {"role": "assistant", "content": "FINAL_JSON: " + (json.dumps(obj) if inv2 == 0 else "{}")},
                ])
                if inv2 == 0:
                    break

        # Validate schema & simple bounds
        w = int(context.get("grid", {}).get("w", 20))
        h = int(context.get("grid", {}).get("h", 20))
        valid_cmds, repairs = _validate_commands(obj, w, h)

        return {"commands": valid_cmds}, {
            "tool_calls": tool_calls,
            "invalid_json": invalid_json,
            "replans": replans,
        }


def make_plan(context: Dict[str, Any], strategy: str = "react", scratchpad: str = "", runner: PlanRunner = None, tick: int = 0) -> Dict[str, Any]:
    """
    Compatibility wrapper. If a PlanRunner is provided, use it to produce the plan and side metrics.
    Otherwise, fall back to a single LLM call and best-effort parsing.
    """
    if runner is not None:
        plan, _stats = runner.plan_tick(tick=tick, context=context, scratchpad=scratchpad)
        return plan

    # Fallback single call by strategy
    if strategy == "plan_execute":
        kind_payload = plan_execute(context, scratchpad=scratchpad)
        raw = kind_payload[1]
    else:
        system = _format_system_prompt(strategy)
        user = _format_user_prompt(context)
        raw = llm_complete(system + "\n\n" + user)
    obj, _inv, _thought = _extract_final_json(raw)
    w = int(context.get("grid", {}).get("w", 20))
    h = int(context.get("grid", {}).get("h", 20))
    cmds, _repairs = _validate_commands(obj, w, h)
    return {"commands": cmds}
