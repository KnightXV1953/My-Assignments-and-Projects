import json
from .llm_client import llm_complete


def plan_execute(context, scratchpad: str = ""):
    """
    Plan-and-Execute style single-tick planner.
    Returns ("final", json_string_of_{"commands": [...]})
    """
    system = (
        "You are CrisisSim's planner using Plan-and-Execute.\n"
        "- First, think a short plan (not too long).\n"
        "- Then emit FINAL_JSON strictly with schema {\"commands\":[...]} only.\n"
    )
    user = (
        "Context JSON (state):\n" + json.dumps(context) + "\n\n"
        "Tool spec:\n"
        "- Commands: move (requires to:[x,y], one-step), or act (action_name in {pickup_survivor, drop_at_hospital, extinguish_fire, clear_rubble, recharge}).\n"
        f"Scratchpad:\n{scratchpad}\n"
    )

    txt = llm_complete(system + "\n\n" + user)
    # Best-effort: pass through to planner for parsing; keep raw here
    return ("final", txt.split("FINAL_JSON:")[-1].strip() if "FINAL_JSON:" in txt else txt)


