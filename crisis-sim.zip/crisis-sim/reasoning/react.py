# reasoning/react.py
import json

def react_plan(context, scratchpad: str = ""):
    """
    Entry point used by planner.make_plan(...):
      returns ("final", <json string of {"commands": [...]}>)
    """
    plan_dict = mock_react_with_tools(context)
    return ("final", json.dumps(plan_dict))


# -------------------- Mock ReAct w/ simple tool reasoning --------------------

def mock_react_with_tools(context: dict) -> dict:
    """
    A self-contained, model-free ReAct-style planner.

    - Medics:
        * If carrying and on a hospital tile -> drop_at_hospital
        * If carrying and not on hospital -> move toward nearest hospital
        * If not carrying:
            - if co-located with a survivor -> pickup_survivor
            - else move toward nearest survivor
    - Truck:
        * If on a fire tile -> extinguish
        * Else move toward nearest fire (via simple BFS one-step path around obstacles)
    - Drone: idle (extend as you like)

    NOTE: Uses simple greedy Manhattan step (no obstacles). The environment
    validates acts (e.g., hospital check) so it's safe if we over-approximate.
    """
    commands = []

    agents = context.get("agents", [])
    fires = [tuple(p) for p in context.get("fires", [])]
    survivors = [tuple(s["pos"]) for s in context.get("survivors", [])]
    hospital_positions = [tuple(h["pos"]) for h in context.get("hospitals", [])]
    hospital_set = set(hospital_positions)
    survivor_set = set(survivors)
    fire_set = set(fires)

    for a in agents:
        aid = a["id"]
        kind = a.get("kind")
        pos = tuple(a.get("pos", (0, 0)))

        if kind == "truck":
            # If standing on fire -> extinguish
            if pos in fire_set:
                commands.append({"agent_id": aid, "type": "act", "action_name": "extinguish"})
                continue
            # low battery or out of water/tools -> head to depot and recharge/restock
            bat = a.get("battery")
            if isinstance(bat, int) and bat <= 5:
                if pos == tuple(context.get("depot", (0,0))):
                    commands.append({"agent_id": aid, "type": "act", "action_name": "recharge"})
                else:
                    nxt = _path_step(pos, tuple(context.get("depot", (0,0))), context)
                    if nxt != pos:
                        commands.append({"agent_id": aid, "type": "move", "to": list(nxt)})
                continue
            # Else go to nearest fire (prefer closer fires)
            tgt = _nearest_from(pos, fires)
            if tgt:
                nxt = _path_step(pos, tgt, context)
                if nxt != pos:
                    commands.append({"agent_id": aid, "type": "move", "to": list(nxt)})

        elif kind == "medic":
            carrying = bool(a.get("carrying", False))
            if carrying:
                # If on hospital -> drop
                if pos in hospital_set:
                    commands.append({"agent_id": aid, "type": "act", "action_name": "drop_at_hospital"})
                else:
                    # prefer nearest hospital with the shortest queue
                    if hospital_positions:
                        hpos = min(hospital_positions, key=lambda hp: _hospital_queue_len(hp, context))
                        nxt = _path_step(pos, hpos, context)
                        if nxt != pos:
                            commands.append({"agent_id": aid, "type": "move", "to": list(nxt)})
            else:
                # If co-located with survivor -> pickup
                if pos in survivor_set:
                    commands.append({"agent_id": aid, "type": "act", "action_name": "pickup_survivor"})
                else:
                    # prioritize survivor with shortest deadline if available
                    s_pos = _nearest_from(pos, survivors)
                    if s_pos:
                        nxt = _path_step(pos, s_pos, context)
                        if nxt != pos:
                            commands.append({"agent_id": aid, "type": "move", "to": list(nxt)})

        elif kind == "drone":
            # basic battery safety: go recharge when low
            bat = a.get("battery")
            if isinstance(bat, int) and bat <= 5:
                if pos == tuple(context.get("depot", (0,0))):
                    commands.append({"agent_id": aid, "type": "act", "action_name": "recharge"})
                else:
                    nxt = _path_step(pos, tuple(context.get("depot", (0,0))), context)
                    if nxt != pos:
                        commands.append({"agent_id": aid, "type": "move", "to": list(nxt)})
            # otherwise idle

    return {"commands": commands}


# -------------------- Helpers --------------------

def _manhattan(a, b) -> int:
    return abs(a[0] - b[0]) + abs(a[1] - b[1])

def _nearest_from(pos, points):
    if not points:
        return None
    return min(points, key=lambda p: _manhattan(pos, p))

def _path_step(src, dst, context):
    """One step toward dst using BFS on a 4-connected grid avoiding fires/rubble."""
    if src == dst:
        return src
    w = int(context.get("grid", {}).get("w", 20))
    h = int(context.get("grid", {}).get("h", 20))
    blocked = set(tuple(p) for p in context.get("fires", [])) | set(tuple(p) for p in context.get("rubble", []))
    sx, sy = src
    if not (0 <= sx < w and 0 <= sy < h):
        return src
    from collections import deque
    q = deque([src])
    came = {src: None}
    while q:
        cur = q.popleft()
        if cur == dst:
            break
        x, y = cur
        for dx, dy in [(1,0),(-1,0),(0,1),(0,-1)]:
            nx, ny = x+dx, y+dy
            np = (nx, ny)
            if 0 <= nx < w and 0 <= ny < h and np not in blocked and np not in came:
                came[np] = cur
                q.append(np)
    if dst not in came:
        # fallback greedy if no route
        sx, sy = src
        dx, dy = dst
        if sx < dx and (sx+1, sy) not in blocked and sx+1 < w:
            return (sx+1, sy)
        if sx > dx and (sx-1, sy) not in blocked and sx-1 >= 0:
            return (sx-1, sy)
        if sy < dy and (sx, sy+1) not in blocked and sy+1 < h:
            return (sx, sy+1)
        if sy > dy and (sx, sy-1) not in blocked and sy-1 >= 0:
            return (sx, sy-1)
        return src
    # reconstruct one step
    node = dst
    path = [node]
    while node != src:
        node = came.get(node)
        path.append(node)
    path.reverse()
    return path[1] if len(path) > 1 else src


def _hospital_queue_len(hp, context):
    # try to find a queue length in context.hospitals
    try:
        for h in context.get("hospitals", []):
            if tuple(h.get("pos", ())) == tuple(hp):
                return int(h.get("queue_len", 0))
    except Exception:
        pass
    return 0
