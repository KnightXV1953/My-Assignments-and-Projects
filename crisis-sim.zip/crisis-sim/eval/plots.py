import argparse, os, glob, pandas as pd
import matplotlib.pyplot as plt

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", type=str, default="results")
    ap.add_argument("--out", type=str, default="results/plots")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    files = glob.glob(os.path.join(args.input, "*.csv"))
    if not files:
        print("No CSVs found in", args.input)
        return

    df = pd.concat([pd.read_csv(f) for f in files], ignore_index=True)

    g = df.groupby(["map","strategy","provider"]) ["crisis_score"].agg(["mean","std"]).reset_index()
    labels = g.apply(lambda r: f"{r['map']}\n{r['strategy']}\n{r['provider']}", axis=1)
    plt.figure()
    plt.bar(labels, g["mean"])
    plt.title("CrisisScore by map × strategy × provider (mean)")
    plt.ylabel("CrisisScore")
    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()
    plt.savefig(os.path.join(args.out, "crisis_score_comparison.png"))
    plt.close()

    # 1) Bar: rescued and deaths by strategy × map
    plt.figure()
    g2 = df.groupby(["map","strategy"]).agg({"rescued":"mean","deaths":"mean"}).reset_index()
    labels2 = g2.apply(lambda r: f"{r['map']}\n{r['strategy']}", axis=1)
    x = range(len(labels2))
    plt.bar([i-0.2 for i in x], g2["rescued"], width=0.4, label="rescued")
    plt.bar([i+0.2 for i in x], g2["deaths"], width=0.4, label="deaths")
    plt.xticks(x, labels2, rotation=45, ha="right")
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(args.out, "bar_rescued_deaths_by_strategy_map.png"))
    plt.close()

    # 3) Box: average rescue time per strategy
    plt.figure()
    df.boxplot(column="avg_rescue_time", by="strategy")
    plt.suptitle("")
    plt.title("Average rescue time per strategy")
    plt.ylabel("ticks")
    plt.tight_layout()
    plt.savefig(os.path.join(args.out, "box_avg_rescue_time_by_strategy.png"))
    plt.close()

    print("Plots saved to", args.out)

if __name__ == "__main__":
    main()
