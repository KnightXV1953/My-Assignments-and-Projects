#include<iostream>
using namespace std;

int arr1(int [],int);
int arr2(int [],int);
int arr3(int [],int);

int myfunction1 (int X[],int Y[],int Z[],int A[],int len,int a,int b,int c);

int main(){
int X[50];
int Y[50];
int Z[50];       

int m,n,x;

cout<<"Enter sizes of  all 3 Array one by one \n";
cin>>m>>n>>x;

cout<<"Enter elements of 1st array\n";         //inputting elements of array number 1
for(int i=0;i<m;i++){
    cin>>X[i];
}
arr1(X,m);


cout<<"Enter elements of 2nd array\n";        //inputting elements of array number 2
for(int i=0;i<n;i++){
    cin>>Y[i];
}
arr2(Y,n); 



cout<<"Enter elements of 3rd array\n";        //inputting elements of array number 3
for(int i=0;i<x;i++){
    cin>>Z[i];
}
arr3(Z,x);

int A[50];
int sd=x+m+n;
A[sd];

myfunction1(X,Y,Z,A,sd,m-1,n-1,x-1);

}

int arr1(int arr1[],int x)         
{
int temp;                                    //sorting array number 1
for(int i=0;i<x;i++){
    for(int j=i+1;j<x;j++){
       if(arr1[i]>arr1[j]){
          temp=arr1[i];
          arr1[i]=arr1[j];
          arr1[j]=temp;
        } 
       else{
            continue;
        }
    }
   
}
}

int arr2(int arr1[],int x)                  //sorting array number 2
{
int temp;
for(int i=0;i<x;i++){
    for(int j=i+1;j<x;j++){
       if(arr1[i]>arr1[j]){
          temp=arr1[i];
          arr1[i]=arr1[j];
          arr1[j]=temp;
        } 
       else{
            continue;
        }
    }  
}
}

int arr3(int arr1[],int x)                 //sorting array number 3
{
int temp;
for(int i=0;i<x;i++){
    for(int j=i+1;j<x;j++){
       if(arr1[i]>arr1[j]){
          temp=arr1[i];
          arr1[i]=arr1[j];
          arr1[j]=temp;
        } 
       else{
            continue;
        }
    }
   
}

}

//Merged Array
int myfunction1(int X[],int Y[],int Z[],int P[],int len,int a,int b,int c){
    
for(int i=0;(i<len);i++){
 
 
 if((Y[b]>=X[a])&&(Y[b]>=Z[c])){
     
        P[i]=Y[b]; 
        b--;
        if(b<0)
        {
        Y[b]=0;
         }
 }
 
 else if((X[a]>=Y[b])&&(X[a]>=Z[c])){
      
        P[i]=X[a];
        a--;  
        if(a<0)        
        {
          X[a]=0;   
         }
 }
 else if((Z[c]>=Y[b])&&(Z[c]>=X[a])){
    
        P[i]=Z[c];
        c--;
        if(c<0)
        {
         Z[c]=0;
         }                        
 }

}

cout<<"New sorted array in Descending order will be\n";
for(int i=0;i<len;i++){
    cout<<P[i]<<" ";
}
}



