#include<iostream>
using namespace std;
void addition(int arr1[50], int arr2[50]);
int main()
	{
	int arr_1[50], arr_2[50];
	addition(arr_1, arr_2);
	return 0;
	}


void addition(int arr1[50], int arr2[50])
	{
	int count1=0, count2=0, x;
	char ch;
	cout<<"Enter the elements of the first array:";
	int i=0;
	while(ch!='Q')
		{
		cin>>arr1[i];
		i++;
		count1++;
		cout<<"Do you wish to add more values?(Press Q to stop) and Press Y to enter more values";
		cin>>ch;
		cout<<endl;
		}
	ch='A';	
	cout<<"Enter the elements of the second array:";
	int j=0;
	while(ch!='Q')
		{
		cin>>arr2[j];
		j++;
		count2++;
		cout<<"Do you wish to add more values?(Press Q to stop) and Press Y to enter more values";
		cin>>ch;
		cout<<endl;
		}
		
	if(count1!=count2)
	{
			x=count2-count1;
			for(int m=count1+1; m<count2+1; m++)
				{
				arr1[m]=0;
				}
			for(int p=0; p<count2; p++)
			{
			cout<<arr1[p];
			}
			cout<<endl;
			for(int q=0; q<count2; q++)
			{
			cout<<arr2[q];
			}
			cout<<endl;
			cout<<"The vector sum of two arrays is:";	
			for(int n=0; n<count2; n++)
				{
				cout<<arr1[n]+arr2[n]<<"\t";
				
				}		
			}
	
		else	{
			x=count1-count2;
			for(int m=count2+1; m<count1+1; m++)
				{
				arr2[m]=0;
				}
			for(int p=0; p<count1; p++)
			{
			cout<<arr1[p];
			}
			cout<<endl;
			for(int q=0; q<count1; q++)
			{
			cout<<arr2[q];
			}
			cout<<endl;	
			cout<<"The required Sum of two arrays are :"<<endl;
			for(int n=0; n<count1; n++)
				{
				cout<<arr1[n]+arr2[n]<<endl;
				
				}	
				
			}
			
		}
	
	





