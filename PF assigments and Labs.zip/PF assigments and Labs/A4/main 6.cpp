#include<iostream>
using namespace std;
void myfunction1();
int main()
{
myfunction1();
return 0;
}
void myfunction1(){
    int a;
    cout<<"Enter the size of array 1 and array 2"<<endl;
    cin>>a;
    int arr1[a];
    for(int k=0; k<a; k++)
    {
        cout<<"Enter elements in array 1"<<endl; 
        cin>>arr1[k];
    }
    cout<<endl;
    int arr2[a];
    for(int j=0; j<a; j++)
    {
        cout<<"Enter elements in array 2"<<endl;
        cin>>arr2[j];
    }
    int k=0;
    int j=0;
    int b=2*a;
    int arr3[b];
    for(int i=0; i<b; i++)
    {
        if(i%2==0)
        {
            arr3[i]=arr1[k];
            k++;
        }
        else
        {
            arr3[i]=arr2[j];
            j++;
        }
    }
    cout<<"\nMerged array is :";
    for(int i=0; i<b; i++)
    {
        cout<<"\t";
        cout<<arr3[i];
       
    }
     
        
       
        
      
    }
    

    
    





