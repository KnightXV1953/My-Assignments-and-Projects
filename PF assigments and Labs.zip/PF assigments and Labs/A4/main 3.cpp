#include <iostream>
using namespace std;
 
void maxint(int arr[], int N, int K)          //body of function
{
    int j, max;
    for(int v=0; v<6; v++)                   //for loop to enter values in  array
    {
        cout<<"enter 6  values u want in array at position "<< " " <<v<<endl;
        cin>>arr[v];
    }
 
    for (int n = 0; n <= N - K; n++) {
        max = arr[n];
 
        for (int i = 1; i < K; i++) {
            if (arr[n + i] > max)
                max = arr[n + i];
        }
        cout << max << " ";          // to display max number in declared window
    }
}
 
int main()
{
    int K;
    int arr[6];
    int N = sizeof(arr) / sizeof(arr[0]);
    cout<<"enter the value of K"<<endl;
    cin>>K;
   
    maxint(arr, N, K);       //calling
    return 0;
}
