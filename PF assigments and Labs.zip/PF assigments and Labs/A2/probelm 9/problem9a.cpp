#include <iostream>
using namespace std;

int main()
{
	
	int x;
	int y;
	int z;
	int maximum;
	
	cout<<"enter the value of x"<<endl;
	cin>>x;
	cout<<"enter value of y"<<endl;
	cin>>y;
	cout<<"enter the value of z"<<endl;
	cin>>z;

	

    maximum = (x > y) ? (x > z ? x : z) : (y > z ? y : z);
		
	{
        cout << "Largest number among " << x << "," << y << " and " << z << " is " << maximum <<endl;
       } 

		
	return 0;
}

