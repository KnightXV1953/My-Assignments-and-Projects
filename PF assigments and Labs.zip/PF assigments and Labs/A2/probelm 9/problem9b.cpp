#include <iostream>
using namespace std;

int main()
{
	
	int x;
	int y;
	int z;
	int a;
	int maximum;
	
	cout<<"enter the value of x"<<endl;
	cin>>x;
	cout<<"enter value of y"<<endl;
	cin>>y;
	cout<<"enter the value of z"<<endl;
	cin>>z;
	cout<<"enter the value of a"<<endl;
	cin>>a;
	

    maximum = (x>y && x>z && x>a) ? x : ((y > z && y > a) ? y : (z > a ? z : a));
{
   cout << "Largest number among " << x <<  "," << y <<  "," << z << " and " << a << " is " << maximum <<endl;
}

		
	return 0;
}

