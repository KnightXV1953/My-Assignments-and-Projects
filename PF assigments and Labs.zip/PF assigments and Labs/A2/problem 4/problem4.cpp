#include <iostream>

using namespace std;

int main()
{
char a,b,c,d;
cout<<"Think of a quadrilateral from square, rectangle, kite, rhombus, trapezium and parallelogram and I will guess it .."<<endl;
cout<<"3"<<endl;
cout<<"2"<<endl;
cout<<"1"<<endl;
cout<<"lets start"<<endl;
cout<<"are all sides equal"<<endl;
cin>>a;
cout<<"are all angles equal to 90 degree"<<endl;
cin>>b;
if(((a=='y')||(a=='Y'))&&((b=='y')||(b=='Y')))
{
    cout<<"i got it its a square"<<endl;
}
else if(((a=='y')||(a=='Y'))&&((b=='n')||(b=='N')))
{
    cout<<"i got it its rhombus"<<endl;
}
else if(((a=='n')||(a=='N'))&&((b=='y')||(b=='Y')))
{
    cout<<"i got it its a rectangle"<<endl;
}
else if(((b=='n')||(b=='N'))&&((a=='n')||(a=='N')))
{
    cout<<"are there two pair of parallel sides"<<endl;
    cin>>c;
    if((c=='y')||(c=='Y'))
    cout<<"i got it its a parallelogram"<<endl;
    else if(((a=='n')||(a=='N'))&&((b=='n')||(b=='N'))&&((c=='n')||(c=='N')))
    cout<<"is there one pair of parallel sides"<<endl;
    cin>>d;
    if((d=='y')||(d=='Y'))
    cout<<"i got it its a trapezium"<<endl;
    else
    cout<<"i got it its a kite"<<endl;
}
else
cout<<"its an inappropriate shape"<<endl;
return 0;
}


