#include<iostream>
using namespace std;

int main()

{

int num;
int x;

cout<<"Enter a number:"<<endl;
cin>>num;

x=num & 1;
switch(x)
{
    case 1:
{
    cout<<"given number is odd"<<endl;
    break;
}
    case 0:
{
        cout<<"given number is even"<<endl;
        break;
}
    default:
    cout<<"invalid input"<<endl;
}

return 0;

}

