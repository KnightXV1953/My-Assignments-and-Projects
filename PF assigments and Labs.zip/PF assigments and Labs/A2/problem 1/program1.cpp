#include <iostream>

using namespace std;

int main()
{
   string name;
   long int cnic;
   int gender;
   long int a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x;
   cout<<"enter name"<<endl;
   cin>>name;
   cout<<"enter your cnic"<<endl;
   cin>>cnic;
   a=cnic/1000000000000;
   b=cnic%1000000000000;
   
   c=b/100000000000;
   d=b%100000000000;
   
   e=d/10000000000;
   f=d%10000000000;
   
   g=f/1000000000;
   h=f%1000000000;
   
   i=h/100000000;
   j=h%100000000;
   
   k=j/10000000;
   l=j%10000000;
   
   m=l/1000000;
   n=l%1000000;
   
   o=n/100000;
   p=n%100000;
   
   q=p/10000;
   r=p%10000;
   
   s=r/1000;
   t=r%1000;
   
   u=t/100;
   v=t%100;
   
   w=v/10;
   x=v%10;
   
   
   
   if(x%2==0)
   {
       cout<<"gender is female"<<endl;
   }
   else 
   {
       cout<<"gender is male"<<endl;
   }
   
   
   
   switch(a)
    {
       case 1:
       cout<<"Province of " << name << " is KPK "<<endl;
       cout<<"Division  of " << name << " is KPK-1 "<<endl;
       cout<<"Destrict of " << name << " is KPK-1 "<<endl;
       cout<<"Tehsil of " << name << " is KPK-1 "<<endl;
       cout<<"Union council of " << name << " is KPK-1 "<<endl;
       cout<<" family tree of " << name << " is ";
       cout<<k << m << o << q << s << u << w <<endl;
       
       break;
    
    
       case 2:
       cout<<"Province of " << name << " is FATA "<<endl;
       cout<<"Devision of " << name << " is FATA-1 "<<endl;
       cout<<"Destrict of " << name << " is FATA-1 "<<endl;
       cout<<"Tehsil of " << name << " is FATA-1 "<<endl;
       cout<<"Union council of " << name << " is FATA-1 "<<endl;
       cout<<" family tree of " << name << " is ";
       cout<< k << m << o << q << s << u << w <<endl;
       break;
    
    
       case 3:
       cout<<"Province of " << name << " is Punjab"<<endl;
       cout<<"Devision of " << name << " is Punjab-1 "<<endl;
       cout<<"Destrict of " << name << " is Punjab-1 "<<endl;
       cout<<"Tehsil of " << name << " is Punjab-1 "<<endl;
       cout<<"Union council of " << name << " is Punjab-1 "<<endl;
       cout<<" family tree of " << name << " is ";
       cout<< k << m << o << q << s << u << w <<endl;
       break;
    
    
       case 4:
       cout<<"Province of " << name << " is Sindh"<<endl;
       cout<<"Devision of " << name << " is Sindh-1 "<<endl;
       cout<<"Destrict of " << name << " is Sindh-1 "<<endl;
       cout<<"Tehsil of " << name << " is Sindh-1 "<<endl;
       cout<<"Union council of " << name << " is Sindh-1 "<<endl;
       cout<<" family tree of " << name << " is ";
       cout<< k << m << o << q << s << u << w <<endl;
       
       break;
    
    
       case 5:
       cout<<"Province of " << name << " is balochistan"<<endl;
       cout<<"Devision of " << name << " is balochistan-1 "<<endl;
       cout<<"Destrict of " << name << " is balochistan-1 "<<endl;
       cout<<"Tehsil of " << name << " is balochistan-1 "<<endl;
       cout<<"Union council of " << name << " is balochistan-1 "<<endl;
       cout<<" family tree of " << name << " is ";
       cout<< k << m << o << q << s << u << w <<endl;
       break;
    
    
       case 6:
       cout<<"Province of " << name << " is Islamabad "<<endl;
       cout<<"Devision of " << name << " is Islamabad-1 "<<endl;
       cout<<"Destrict of " << name << " is Islamabad-1 "<<endl;
       cout<<"Tehsil of " << name << " is Islamabad-1 "<<endl;
       cout<<"Union council of " << name << " is Islamabad-1 "<<endl;
       cout<<" family tree of " << name << " is ";
       cout<< k << m << o << q << s << u << w <<endl;
       break;
    }
   
   
   
   
   
   
   
   
   
   
   return 0;
}




