#include <iostream>

using namespace std;

int main()
{
    int numx;
    cout<<"enter the number you want to check"<<endl;
    cin>>numx;
    if(numx>0)
    {
        if((numx&(numx-1))==0)
        {
            cout<<"given number is power of 2"<<endl;
        }
        else
        cout<<"given number is not power of 2"<<endl;
    }
    else
    cout<<"invalid output"<<endl;
}
