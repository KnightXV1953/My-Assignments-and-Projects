#include <iostream>

using namespace std;

int main()
{
    char x;
    cout<<"enter the alphabet"<<endl;
    cin>>x;
    cout<<(((x>='a') && (x<='z')) ? "its lower case alphabet" : ((x>='A') && (x<='Z')) ? "its upper case alphabet" : "invalid input")<<endl;
    cout<<"Thanks!!";

    return 0;
}

