#include <iostream>
using namespace std;
int main()
{
    int lyear;
    cout<<"enter the year"<<endl;
    cin>>lyear;
    
    cout<<(((lyear%100 !=0) && (lyear%4 == 0) || (lyear%4000 == 0) ) ?  "Given year is Leap year" : "Given year is not leap year")<<endl;
return 0;
}

