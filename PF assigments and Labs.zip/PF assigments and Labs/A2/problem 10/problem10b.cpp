#include <iostream>

using namespace std;

int main()
{
   char x;
   cout<<"enter character"<<endl;
   cin>>x;
   
   cout<<(((x>='0') && (x<='9')) ? "its a number" : ((x>='a') && (x<='z') || (x>='A') && (x<='Z')) ? "its an alphabet" : "its a special character") <<endl;

    return 0;
}

