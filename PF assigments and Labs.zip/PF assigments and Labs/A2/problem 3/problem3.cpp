#include<iostream>
using namespace std;
int main()
{
    int wheel;
    int figure;
    int car_body;
    int total_wheel;
    int total_figure;
    
    cout<<"enter wheels"<<endl;
    cin>>wheel;
    cout<<"enter figures"<<endl;
    cin>>figure;
    cout<<"enter car body"<<endl;
    cin>>car_body;
    
    total_wheel = wheel / 4;
    total_figure= figure / 2;
    
     if((total_wheel<=car_body) && (total_wheel<=total_figure))
    {
        cout<<"no.of cars which can be build are"<< total_wheel <<endl;
    }
    else if((total_figure<=car_body) && (total_figure<=total_wheel))
    {
        cout<<"no.of cars which can be build are"<< total_figure <<endl;
    }
    else if((car_body<=total_wheel) && (car_body<=total_figure))
    {
        cout<<"no.of cars which can be build are"<< car_body <<endl;
    }
    else
    {
        cout<<"not enough meterials to build a car"<<endl;
    }
    return 0;
}


