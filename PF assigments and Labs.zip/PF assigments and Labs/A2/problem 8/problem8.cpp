#include<iostream>
using namespace std;
int main()
{
    int no1;
    int no2;
    int average;
    
    cout<<"enter value of number 1:"<<endl;
    cin>>no1;
    cout<<"enter value of number 2:"<<endl;
    cin>>no2;
    
    average= (no1 & no2) ^ ((no1 ^ no2) >> 1);
    cout<<average;
    return 0;
}
