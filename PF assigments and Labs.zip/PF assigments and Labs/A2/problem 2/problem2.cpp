#include <iostream>
#include <time.h>
using namespace std;
int main()
{
    int numtoguess,numweguess;
    srand(time(0));
    numtoguess=rand()%100+1;
    cout<<"Lets play a game, you have to guess a secret number i have thought. You have 5 tries"<<endl;
    cout<<"enter your first guess"<<endl;
    cin>>numweguess;
    if(numweguess<1||numweguess>100)
    {
        cout<<"your number is out of bounds"<<endl;
    }
    else if(numweguess==numtoguess)
    {
    {
            cout<<"you have guessed the right number"<<endl;
    }
        cout<<"you won"<<endl;
        return 0;
    }
    else if(numweguess!=numtoguess)
{
        if(numweguess>numtoguess)
        {
            cout<<"you have guessed too high"<<endl;
        }
        if(numweguess<numtoguess)
        {
            cout<<"you have guessed too low"<<endl;
        }
        cout<<"4 trys left. Guess the number"<<endl;
        cin>>numweguess;
        if(numweguess==numtoguess)
        {
            cout<<"you have guessed right number"<<endl;
            return 0;
        }
        if(numweguess<1||numweguess>100)
        {
            cout<<"your number is out of bounds"<<endl;
        }
        if(numweguess>numtoguess)
        {
            cout<<"your have guessed too high"<<endl;
        }
        if(numweguess<numtoguess)
        {
            cout<<"you have guessed too low"<<endl;
        }
        cout<<"3 trys left. Guess the number"<<endl;
        cin>>numweguess;
        if(numweguess==numtoguess)
        {
            cout<<"you have guessed right number"<<endl;
            return 0;
        }
        if(numweguess<1||numweguess>100)
        {
            cout<<"your number is out of bounds"<<endl;
        }
        if(numweguess>numtoguess)
        {
            cout<<"you have guessed to high"<<endl;
        }
        if(numweguess<numtoguess)
        {
            cout<<"you have guessed too low"<<endl;
        }
        cout<<"2 trys left. Guess the number"<<endl;
        cin>>numweguess;
        if(numweguess==numtoguess)
        {
            cout<<"you have guessed the right number"<<endl;
            return 0;
        }
        if(numweguess<1||numweguess>100)
        {
            cout<<"your number is out of bounds"<<endl;
        }
        if(numweguess>numtoguess)
        {
            cout<<"you have guessed too high"<<endl;
        }
        if(numweguess<numtoguess)
        {
            cout<<"you have guessed too low"<<endl;
        }
        cout<<"last try left. Guess the number"<<endl;
        cin>>numweguess;
        if(numweguess==numtoguess)
        {
            cout<<"you have guessed the right number"<<endl;
            return 0;
        }
        if(numweguess<1||numweguess>100)
        {
            cout<<"your number is out of bounds"<<endl;
        }
        if(numweguess>numtoguess)
        {
            cout<<"you have guessed too high and you are out of trys"<<endl;
        }
        if(numweguess<numtoguess)
        {
            cout<<"you have guessed too low and you are out of trys"<<endl;
        }
        cout<<"correct number was"<<endl;
        cout<<numtoguess;
}
else
cout<<"inappropriate input"<<endl;
    
    
     return 0;
}






