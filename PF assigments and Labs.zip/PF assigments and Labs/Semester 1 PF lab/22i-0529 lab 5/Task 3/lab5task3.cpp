#include <iostream>
using namespace std;
int main()
{
int a=0,b=0,c=0;
cout<<"enter value of a"<<endl;
cin>>a;
cout<<"enter value of b"<<endl;
cin>>b;
cout<<"enter value of c"<<endl;
cin>>c;
if (a<b<c)
{cout<<"a is smallest"<<endl;
}
else if (b<a<c)
{cout<<"b is smallest"<<endl;
}
else if (c<a<b)
{cout<<"c is smallest"<<endl;
}
return 0;
}

