#include <iostream>
using namespace std;
int main()
{
int x = 0 ;


cout<<"enter value of x" <<endl;
cin>>x;
if(x%5==0)
{
cout<<(x*3)+1 <<endl;
}
else
{cout<<x/2;
}
return 0;
}
