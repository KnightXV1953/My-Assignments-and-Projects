#include <iostream>
using namespace std;
int main()
{
int a=0,b=0,c=0,d=0;
cout<<"enter value of a"<<endl;
cin>>a;
cout<<"enter value of b"<<endl;
cin>>b;
cout<<"enter value of c"<<endl;
cin>>c;
cout<<"enter value of d"<<endl;
cin>>d;
if ((a>b)&&(a>c)&&(a>d))
{cout<<"a is greatest of all"<<endl;
}
else if ((b>a)&&(b>c)&&(b>d))
{cout<<"b is greatest of all"<<endl;
}
else if ((c>a)&&(c>b)&&(c>d))
{cout<<"c is greatest of all"<<endl;
}
else if ((d>a)&&(d>b)&&(d>c))
{cout<<"d is greatest of all"<<endl;
}
return 0;
}
