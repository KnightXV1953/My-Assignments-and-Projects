#include <iostream>
using namespace std;
int main()
{
cout<<"Narrated Abu Suffyan:"<<endl;
cout<<"That Heraclius sent for him and said, \"What did He, i.e. the Prophet (PBUH) order you?\".I replied,\"He (PBUH) orders us to offer prayers,to give alms, to be chaste and to keep good relations with our relatives\""<<endl;
return 0;
}
