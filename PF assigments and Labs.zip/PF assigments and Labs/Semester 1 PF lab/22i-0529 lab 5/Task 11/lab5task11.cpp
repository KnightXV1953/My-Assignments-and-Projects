#include <iostream>
using namespace std;
int main()
{
int time;
cout<<"enter time taken by a worker"<<endl;
cin>>time;
if ((time>1)&&(time<2))
{cout<<"worker is highly efficient"<<endl;
}
else if ((time>2)&&(time<3))
{cout<<"improve speed"<<endl;
}
else if ((time>3)&&(time<4))
{cout<<"worker is given training to improve his speed"<<endl;
}
else if ((time>4)&&(time<5))
{cout<<"final warning letter has been issued"<<endl;
}
else if (time>4)
{cout<<"worker has to leave company"<<endl;
}
return 0;
}


