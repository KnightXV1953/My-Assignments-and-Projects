#include <iostream>
using namespace std;
int main()
{
int a,b,c;

cout<<"enter value of a"<<endl;
cin>>a;
cout<<"enter value of b"<<endl;
cin>>b;
cout<<"enter value of c"<<endl;
cin>>c;
if(a+b+c==180)
{
cout<<"triangle is valid"<<endl;
}
else
{
cout<<"not a triangle"<<endl;
}
return 0;
}
