#include <iostream>
using namespace std;
int main ()
{
int days=0;
int charges=0;
cout<<"enter number of days"<<endl;
cin>>days;
if((days>=0)&&(days<=7))
{
cout<<"charges are 10pkr"<<endl;
}
else if((days>=8)&&(days<=14))
{
cout<<"charges are 20pkr"<<endl;
}
else if((days>14))
{
cout<<"charges are 50pkr"<<endl;
}
else if((days>31))
{
cout<<"Membership is cancelled"<<endl;
}
return 0;
}
