#include <iostream>
using namespace std;
int main()
{
int x1,y1,x2,y2,x3,y3,x4,y4,s1,s2;
cout<<"enter value of x1,y1"<<endl;
cin>>x1>>y1;
cout<<"enter value of x2,y2"<<endl;
cin>>x2,y2;
cout<<"enter value of x3,y3"<<endl;
cin>>x3>>y3;
s1=(y2-y1)/(x2-x1);
s2=(y4-y3)/(x4-x3);
if (s1==s2)
{cout<<"points lie on same line or points are collinear"<<endl;
}
else
{cout<<"they dont lie on same line"<<endl;
}


return 0;
}


