//dynamic memory allocation
#include<iostream>
using namespace std;
int main()
{
int *ptr=nullptr;                        //we declared variable dynamically allocate
ptr = new int;       
*ptr=10;                  
cout<<*ptr;
cout<<endl;
delete ptr;            //deleting pointer 

}

