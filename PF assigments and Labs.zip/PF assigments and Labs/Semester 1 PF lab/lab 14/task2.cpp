#include<iostream>
using namespace std;
int  main()
{
int n=5;
int *ptr=nullptr;
//allocation
ptr = new int[n];
for (int i=0; i<n; i++)
{
cout<<"enter value"<<endl;
cin>>ptr[i];
}
for (int i=0; i<n; i++)
{
cout<<ptr[i]; 
cout<<endl;
}
delete[] ptr;
}
