#include<iostream>          //print sum using pointer
using namespace std;
int main()
{
int x=10;
int y=20;
int z=0;
int *p1=nullptr;
int *p2=nullptr;
int *p3=nullptr;
p1=&x;
p2=&y;
p3=&z;
*p3=*p1 + *p2;
cout<<*p3;













}
