#include<iostream>
using namespace std;
//prototype
void display(int *);
int main()
{
int x=100;
int *p=nullptr;
p=&x;
//function calling
display(p);
}
//definetion
void display(int *p)
{
cout<<*p;
}

