#include<iostream>
using namespace std;
int main()
{
int x=10;
int y=20;
int temp=0;
cout<<x<<endl;
cout<<y<<endl;
int *p1=nullptr;
int *p2=nullptr;
int *p3=nullptr;
p1=&x;
p2=&y;
p3=&temp;
*p3=*p1;
*p1=*p2;
*p2=*p3;
cout<<"The value of x is "<<*p1;
cout<<endl;
cout<<"The value of y is" <<*p2; 
cout<<endl;
}
