#include<iostream>
using namespace std;
void average( float *, float *, float *, float * , float * );
int main()
{
float x1=5,x2=10,x3=20,x4=30,x5=50;
float *p1=nullptr;
float *p2=nullptr;
float *p3=nullptr;
float *p4=nullptr;
float *p5=nullptr;
p1=&x1;
p2=&x2;
p3=&x3;
p4=&x4;
p5=&x5;
average (p1 , p2 , p3 , p4 , p5);
}
//definetion
void average(float *p1 ,float *p2, float *p3, float *p4, float *p5)
{
float average=0;
float *p6=nullptr;
p6=&average;
*p6=(*p1 + *p2 + *p3 + *p4 + *p5)/5;
cout<<"Average of 5 numbers is"<<*p6<<endl;
}
