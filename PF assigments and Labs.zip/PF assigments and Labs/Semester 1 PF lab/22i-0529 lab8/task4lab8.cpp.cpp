#include <iostream>
using namespace std;
int main()
{
int x=0;
int sum=0;
do
{
cout<<"enter the number"<<endl;
cin>>x;
sum+=x;
}
while(x>=0);
{
cout<<" sum of numbers is "<< sum  <<endl;
}
return 0;
}


