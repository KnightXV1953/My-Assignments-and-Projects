#include<iostream>
using namespace std;
int main()
{
cout<<"Hadith from Al-Bukhari #7392 which Abu Huraira Reports the Messenger of Allah (pbuh) as saying,\"Allah has ninety-nine Names, one hundred less one; and he who memorized them all by heart will enter Paradise.\""<<endl;
return 0;
}
