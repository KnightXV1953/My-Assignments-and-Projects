#include <iostream>
using namespace std;
int main()
{
int x=0;
int sum=0;
int sum1=0;
while(x>=0)
{
    
cout<<"enter value of x"<<endl;
cin>>x;
if(x>0)
sum+=x;
else
cout<<"you have entered negative number"<<endl;

}
cout<<" Total sum will be " << sum<<endl;
return 0;
}
