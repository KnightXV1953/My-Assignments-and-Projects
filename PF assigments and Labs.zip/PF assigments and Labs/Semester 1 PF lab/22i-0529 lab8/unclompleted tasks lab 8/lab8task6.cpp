#include<iostream>
using namespace std;
int main()
{
int x,p=2,q=5;
while(x>0)
{
cout<<"enter a number"<<endl;
cin>>x;
if((x%p)!=0)
{
cout << x <<" is prime number"<<endl;
}
else
{
cout << x <<" is not prime number"<<endl;
}
}
return 0;
}

