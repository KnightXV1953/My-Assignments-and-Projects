#include <iostream>
using namespace std;
int main()
{
int x=0,maximum=0,minimum=0;
cout<<"enter any integer"<<endl;
cin>>x;
while(x!=0)
{
if(x>maximum)
{
maximum=x;
}
else if(x<minimum)
{
minimum=x;
}
cout<<"enter any integer"<<endl;
cin>>x;
}
cout<<"the maximum number is " << maximum <<endl;
cout<<"the minimum number is " << minimum <<endl;
return 0;
}
