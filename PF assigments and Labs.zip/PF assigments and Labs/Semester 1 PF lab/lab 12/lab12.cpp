#include<iostream>
using namespace std;
void task7();
void task2();
void task3();
void insertinto(int array[5][5]);
void sumtwo(int array[5][5]);
void square(int &value);

int main()
{
int choice;
cout<<"Press 7 for task 7\n Press 2 for task 2 \n Press 3 for task3 "<<endl;
cin>>choice;
switch(choice)
{
case 3:
task3();
break;
case 2:
{
task2();
break;
}
case 7:
task7();
break;
}
}
void task7()
{
int arr[5][5];
int arr1[5][5];
int arrsum[5][5];

for (int i=0;i<5 ;i++ )
{
     for(int j=0;j<5;j++)
     {
     cout <<"enter number of row " << i << "and column" << j << endl;
     cin >> arr[i][j]; 
     }
     
}

for (int i=0;i<5;i++)
{
     for(int j=0;j<5;j++)
     {
     cout << " enter number of row " << i << "and column" << j << endl;
     cin >> arr1[i][j]; 
     }
     
}

for (int i = 0 ; i < 5 ; i++)
{
     for (int j = 0 ; j < 5 ; j++ )
     {
     arrsum[i][j] = arr[i][j] + arr1[i][j];
     }
}

for (int i = 0 ; i < 5 ; i++ )
{
     for (int j = 0 ; j < 5 ; j++)
     {
     cout << arrsum[i][j] << "  " ;
     }
     cout << endl;
}









}

void task2()
{
int array[5][5];
insertinto(array);
sumtwo(array);
}
void insertinto(int array[5][5])
{
for(int i=0;i<5;i++)
{
	for(int j=0;j<5;j++)
	{
		cout<<"Elements for Row "<<i<<" Column "<<j<<endl;
		cin>>array[i][j];
	}
}
for(int i=0;i<5;i++)
{
	for(int j=0;j<5;j++)
	{
		
		cout<<array[i][j]<<" ";
	}
cout<<endl;
}
}
void sumtwo(int array[5][5])
{
for(int i=0;i<5;i++)
{
	for(int j=0;j<5;j++)
	{
	  array[i][j]=array[i][j]+2;
	}
}
for(int i=0;i<5;i++)
{
	for(int j=0;j<5;j++)
	{
	  cout<<array[i][j]<<" ";
	}
cout<<endl;
}
}
void task3()
{
int value;
cout<<"enter a value"<<endl;
cin>>value;	
square(value);
cout<<value<<endl;
}
void square(int &value)
{
value=value*value;
}

