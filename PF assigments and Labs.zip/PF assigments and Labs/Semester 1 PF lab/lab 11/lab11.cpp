#include <iostream>
using namespace std;

void samplechoice();
void task2();
void task3();
void task4();
void task7();
int main()
{
 samplechoice();
}
void samplechoice(){
int userchoice;
cout<<"which task you want to see"<<endl;
cin>>userchoice;
switch(userchoice)
{
case 2:
task2();
break;
case 3:
task3();
break;
}
}

void task2(){
     int array[10]={};
    for(int i=0; i<10; i++)
    {
        cout<<"enter elements in array at index"<< " " << i <<endl;
        cin>>array[i];
    }
        
    for(int j=0; j<10; j++)
    {
        int count=0;
        for(int k=0; k<10; k++)
        {
            if(array[j]==array[k])
            {
                count++;
            }
        }
        cout<<"count of"<< " " <<array[j] <<" "<< "is" << " " << count<<endl;
    }

        for (int i=0;i<9;i++) 
    {
		for (int j=i+1;j<10;j++) 
		{
			if (array[i]>array[j]) 
			{
				int temp=array[i];
				array[i]=array[j];
				array[j]=temp;
			}
		}
	}
    int A[20];
    int x=0;
    for(int i=0;i<10;i++)
    {
        if(array[i]!=array[i+1])
        {
            A[x]=array[i];
            x++;
        }
    }
      A[x]=array[9];
    for(int i=0;i<x;i++)
    {
        array[i]=A[i];
    }
    for(int i=0;i<x;i++)
    {
        cout<<"sorted array after removing duplicate items will be"<<endl;
        cout<<array[i]<<" ";
    }
    
    }
        
void task3(){
    
    int array[10];
        for(int i=0; i<10; i++)
        {
            cout<<"enter value of element at"<<" "<<i<<endl;
            cin>>array[i];
        }
        int temp=0;
        for(int j=0; j<10; j=j+2)
        {
            temp=array[j];
            array[j]=array[j+1];
            array[j+1]=temp;
        }
        cout<<"Array after swapping one time will be: "<<endl;
        for(int k=0; k<10; k++)
        {
            cout<<array[k];
        }
        cout<<endl;
        int temp2 = 0;
        for(int i=0; i<10; i=i+2)
        {
            temp2 = array[i];
            array[i]=array[i+1];
            array[i+1]=temp2;
        }
        cout<<"Array after swapping two time will be :"<<endl;
        for(int i=0; i<10; i++)
        {
            cout<<array[i];
        }
        
}





