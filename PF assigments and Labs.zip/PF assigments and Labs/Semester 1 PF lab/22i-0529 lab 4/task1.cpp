#include <iostream>
using namespace std;
int main()
{
int A;
int B;
int C;
cout<<"enter value of A" <<endl;
cin>>A;
cout<<"enter value of B" <<endl;
cin>>B;
C=A&&B;
cout<<C;


return 0;
}

