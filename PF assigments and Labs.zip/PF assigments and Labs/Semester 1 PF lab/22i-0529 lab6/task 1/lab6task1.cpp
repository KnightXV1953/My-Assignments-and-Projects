#include <iostream>
using namespace std;
int main ()
{
cout<<"ibn Umar and Abu Hurairah (may Allah be pleased with them) reported:"<<endl;
cout<<"We heard the messenger of Allah saying (while delivering Khutbah on his wooden pulpit),"<<endl;
cout<<"\"Either some people stop neglecting the Friday prayers, or Allah will seal their hearts and they will be among the heedless.\"(Muslim)"<<endl;
return 0;
}
