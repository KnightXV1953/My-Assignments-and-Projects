#include <iostream>
using namespace std;
int main()
{
int num1,num2;
char oper;
cout<<"menu"<<endl;
cout<<"+ addition"<<endl;
cout<<"- subtraction"<<endl;
cout<<"* multiplication"<<endl;
cout<<"/ devision"<<endl;
cout<<". cancellation"<<endl;
cout<<"enter number 1"<<endl;
cin>>num1;
cout<<"enter number 2"<<endl;
cin>>num2;
cout<<"enter operator from above"<<endl;
cin>>oper;
switch(oper)
{
case('+'):
cout<<num1+num2;
break;
case('-'):
cout<<num1-num2;
break;
case('*'):
cout<<num1*num2;
break;
case('/'):
cout<<num1/num2;
break;
case('.'):
cout<<"operation is cancelled"<<endl;
break;
default:
cout<<"doesnt match any above operator"<<endl;
}
return 0;
}

