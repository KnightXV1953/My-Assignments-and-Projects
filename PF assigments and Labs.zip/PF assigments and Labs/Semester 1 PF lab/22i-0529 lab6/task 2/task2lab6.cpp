#include <iostream>
using namespace std;
int main()
{
int cgpa;
cout<<"enter your cgpa"<<endl;
cin>>cgpa;
if(cgpa==4)
cout<<"your grade is A+"<<endl;
else if((cgpa>=3)&&(cgpa<4))
cout<<"your grade is A";
else if(cgpa==2)
cout<<"your grade is B"<<endl;
else if(cgpa==1)
cout<<"your grade is C"<<endl;
return 0;
}
