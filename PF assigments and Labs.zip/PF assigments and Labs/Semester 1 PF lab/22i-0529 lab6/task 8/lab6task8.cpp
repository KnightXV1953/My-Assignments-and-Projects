#include <iostream>
using namespace std;
int main()
{
int units;
float amount,bill,increase;
cout<<"enter the amount of units consumed"<<endl;
cin>>units;
switch(units==50)
{
case 1:
{
bill=(units*0.50);
increase=(bill/100)*20;
bill=bill+increase;
cout<<"bill is"<<endl;
cout<<bill;
break;
}
case 0:
{
switch((units>=50 && units<150))
{
case 1:
{
bill=(units*0.75);
increase=(bill/100)*20;
bill=bill+increase;
cout<<"bill is"<<endl;
cout<<bill;
break;
}
case 0:
{
switch((units>150) && (units<=250))
{
case 1:
{
bill=(units*1.20);
increase=(bill/100)*20;
bill=bill+increase;
cout<<"bill is"<<endl;
cout<<bill;
break;
}
case 0:
{
switch(units>250)
{
case 1:
{
bill=(units*1.50);
increase=(bill/100)*20;
bill=bill+increase;
cout<<"bill is"<<endl;
cout<<bill;
break;
}
}
}
}
}
}
}
}
return 0;
}


