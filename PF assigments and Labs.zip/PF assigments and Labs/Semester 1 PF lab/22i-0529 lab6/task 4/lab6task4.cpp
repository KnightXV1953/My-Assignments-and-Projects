#include <iostream>
using namespace std;
int main()
{
int num1,num2;
cout<<"enter number 1"<<endl;
cin>>num1;
cout<<"enter number 2"<<endl;
cin>>num2;
switch(num1>num2)
{
case 1:
{
cout<<"num 1 is greater then num 2"<<endl;
break;
}
case 0:
switch(num2>num1)
{
case 1:
cout<<"number 2 is greater then number 1"<<endl;
break;

case 0:
switch(num2==1)
{
case 1:
cout<<"both numbers are equal"<<endl;
break;
}}
default:
cout<<"lmao imagine"<<endl;
break;
}
return 0;
}

