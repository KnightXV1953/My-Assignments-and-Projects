#include <iostream>
using namespace std;
int main()
{
int score;
cout<<"whats your score"<<endl;
cin>>score;
switch(score>=90)
{
case 1:
cout<<"your grade is A+"<<endl;
break;
case 0:
switch((score<89) && (score>=80))
{
case 1:
cout<<"your grade is A"<<endl;
break;
case 0:
switch((score<=79) && (score>=70))
{
case 1:
cout<<"your grade is B"<<endl;
break;
case 0:
switch((score<=69)&&(score>=60))
{
case 1:
cout<<"your grade is C"<<endl;
break;
case 0:
switch((score<=59)&&(score>=50))
{
case 1:
cout<<"your grade is D" <<endl;
break;
case 0:
switch(score<50)
{
case 1:
cout<<"your grade is F.You are fail"<<endl;
break;
default:
cout<<"invalid input"<<endl;
}
}
}
}
}
}
return 0;
}


