#include <iostream>
using namespace std;
int main()
{
char x;
cout<<"enter input value"<<endl;
cin>>x;
switch((x>='a' && x<='z') || (x>='A' && x<='Z'))
{
case 1:
cout<<"it is an alphabet"<<endl;
break;
case 0:
{
switch (x>='0')
{
case 1:
cout<<"it is a number"<<endl;
break;
case 0:
cout<<"it is a special character"<<endl;
break;
}
}
cout<<"thanks"<<endl;
return 0;
}
}
