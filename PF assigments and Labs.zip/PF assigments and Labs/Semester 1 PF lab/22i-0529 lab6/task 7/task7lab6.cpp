#include <iostream>
using namespace std;
int main()
{
int day;
cout<<"enter a number "<<endl;
cin>>day;
switch(day)
{
case 1:
{
cout<<"day is friday!! huh"<<endl;
}
break;
case 2:
{
cout<<"day is saturday "<<endl;
}
break;
case 3:
{
cout<<"day is sundayy"<<endl;
}
break;
case 4:
{
cout<<"day is monday"<<endl;
}
break;
case 5:
{
cout<<"day is tuesday"<<endl;
}
break;
case 6:
{
cout<<"day is wednesday"<<endl;
}
break;
case 7:
{
cout<<"day is thursday"<<endl;
}
break;
}
return 0;
}
