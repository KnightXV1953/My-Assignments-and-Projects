#include <SFML/Graphics.hpp>
#include<SFML/Audio.hpp>
#include<SFML/Network.hpp>
#include<iostream>
#include <time.h>
using namespace sf;
using namespace std;

 
 int main()
{
    RenderWindow window(VideoMode(740,480), "TEXT");
 
     Font font;
      font.loadFromFile("Kandel.otf");
     
     
    Text text("Game Over", font);
    
	text.setCharacterSize(70);
	
	text.setFillColor(Color::White);
	
	text.setStyle(Text::Bold);
	
	text.setPosition(150.f, 60.f);
	
	Text text3("Press escape to exit the game window!",font);
	text3.setCharacterSize(20);
	
	text3.setFillColor(Color::White);
	
	text3.setStyle(Text::Bold);
	
	text3.setPosition(130.f, 160.f);
	
	
	
  while (window.isOpen())
  {   
  Event event;
 
while(window.pollEvent(event))
{
    if(event.type == Event::Closed)
        window.close();
    else if(event.type == Event::KeyPressed)
    {
        if(event.key.code == Keyboard::Key::Escape)
            window.close();
        
       
    
    }
}
  	window.clear();
  	 window.draw(text); 
 	 window.draw(text3);
  	 window.display();

   
  }
    return 0;
}



