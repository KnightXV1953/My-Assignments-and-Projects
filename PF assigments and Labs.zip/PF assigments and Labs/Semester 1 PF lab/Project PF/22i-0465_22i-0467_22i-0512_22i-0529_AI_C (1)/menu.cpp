#include <SFML/Graphics.hpp>
#include<SFML/Audio.hpp>
#include<iostream>
#include <time.h>
using namespace sf;
using namespace std;

 
 int main()
{
    RenderWindow window(VideoMode(740,480), "TEXT");
    
    RectangleShape rectangle(Vector2f(120.f, 50.f));
    rectangle.setSize(Vector2f(180.f, 100.f));
    rectangle.setPosition(250.f, 180.f);
    rectangle.setFillColor(Color::Yellow);
    
 
     Font font;
      font.loadFromFile("Kandel.otf");
     
     
    Text text("Start", font);
    
	text.setCharacterSize(50);
	
	text.setFillColor(Color::White);
	
	text.setStyle(Text::Bold);
	
	text.setPosition(250.f, 180.f);
	
	
    	 
  while (window.isOpen())
  {   
  Event event;
  while(window.pollEvent(event))
  	{
  	if(event.type==Event::Closed)
  		{
  		window.close();
  		}
  		
  
  	}
  	
  	
  	window.clear();
  	window.draw(rectangle);
  	 window.draw(text); 
  	 window.display();

   
  }
    return 0;
}



