
//Syeda Abeeha Batool-22i_0465  swapping, scorebar
//Uriba Parveen Khan-22i_0467   audio, get and display score, delete animation
//Muhammad Ali Taha-22i_0529    timer, app open and close, tilesize
//Ali Hussain-22i_0512		 game board, grid adjustment, background image 


#include <SFML/Graphics.hpp>			//for images
//#include <SFML/Audio.hpp>			//for sound
#include <time.h>				//for srand i.e. to randomly add new tiles after the matching of previous ones
#include <iostream>			

using namespace sf;				//used for sfml
using namespace std;				


int ts = 54; 		//tile size
Vector2i offset(48, 24);		//for grid positioning(it is a vector) 

struct piece				//to group all the variables of any data type in one place
{
    int x, y, c, r, type, match, alpha;
    piece() 
    { 
    match = 0; alpha = 255;
    } 					//alpha is used for transparency, match is used for searching & working on the specified items
} 
grid[10][10];		//2D array


void swap(piece p1, piece p2)
{
    swap(p1.c, p2.c);
    swap(p1.r, p2.r);

    grid[p1.r][p1.c] = p1;
    grid[p2.r][p2.c] = p2;
}


int main()
{
    srand(time(0));		//to randomly display new images before or after matching

    RenderWindow app(VideoMode(1920, 1080), "Manjeeelay");	//create window and setting resoluton


sf::Time micro = sf::microseconds( 10000);                  //for timer
sf::Time milli = sf::milliseconds(10);
sf::Time seconds = sf::seconds(0.01f);

sf:: Clock clock;			//used to measure time 

 
   /* Music music;				//audio module
    music.openFromFile("jaan1.ogg");		//used to load and open file from file
    music.setLoop(true);			//used to repeat the song 
    music.play();
    */


    app.setFramerateLimit(144);		//used for smoothness and to run the app for the given time span

    Texture t1, t2;				//graphic module that stores pixels of the sprites
    t1.loadFromFile("sprites/background.png");	//to load the image from file
    t2.loadFromFile("sprites/animals.png");

    Sprite background(t1), animals(t2);		// graphic module which is just a rectamgular textured box 


    //positioning as well as assigning random values
    for (int i = 1;i <= 8;i++)			 
        for (int j = 1;j <= 8;j++)
        {
            grid[i][j].type = rand() % 3;	
            grid[i][j].c = j;
            grid[i][j].r = i;
            grid[i][j].x = j * ts;
            grid[i][j].y = i * ts;
        }


    int x0, y0, x, y; int click = 0; Vector2i pos;
    bool isSwap = false, isMoving = false;


    int timer=0;

Font font;
    font.loadFromFile("Kandel.otf");		//graphic module used for loading font style from the file
     
    Text text("Score=", font);		//graphic module for declaring text to dsiplay
    
    
	text.setCharacterSize(40);
	
	text.setFillColor(Color::White);
	
	text.setStyle(Text::Bold);
	
	text.setPosition(520.f, 30.f);
	
	
	int sc=15;			//size and score of the scorebar
	RectangleShape ScoreBar;		//graphic module for creating shapes
	ScoreBar.setFillColor(Color::Green);	//formatting of the scorebar
	ScoreBar.setOutlineThickness(2);
	ScoreBar.setOutlineColor(Color::Black);
	ScoreBar.setPosition(500, 150);

	
    while (app.isOpen())		//loop to perform operations when app is open
    {
        Event event;
        while (app.pollEvent(event))	//checks if there is a pending event or not(if yes it returns 1 to loop else it returns 0)
        {
            if (event.type == Event::Closed)	//Checks when user presses exit button to exit the window
                app.close();
           

            if (event.type == Event::MouseButtonPressed)	//checks when the user presses the mouse button
                if (event.key.code == Mouse::Left)		//checks if user presses left button of mouse
                {
                    if (!isSwap && !isMoving) click++;	
                    pos = Mouse::getPosition(app) - offset;	//range in which the mouse will work
                    
                }
        }

        //swapping positions on mouse
        if (click == 1)			 
        {
            x0 = pos.x / ts + 1;
            y0 = pos.y / ts + 1;
        }
        if (click == 2)
        {
            x = pos.x / ts + 1;
            y = pos.y / ts + 1;
            if (abs(x - x0) + abs(y - y0) == 1)		//if the condition is true, tiles will be swapped accordingly
            {
                swap(grid[y0][x0], grid[y][x]); isSwap = 1; click = 0;}
            else click = 1;
        }

        //Match finding
        for (int i = 1;i <= 8;i++)
            for (int j = 1;j <= 8;j++)
            {
                if (grid[i][j].type == grid[i + 1][j].type)		//check for match in row
                    if (grid[i][j].type == grid[i - 1][j].type)
                        for (int n = -1;n <= 1;n++) 
                        grid[i + n][j].match++;

                if (grid[i][j].type == grid[i][j + 1].type)		//for column
                    if (grid[i][j].type == grid[i][j - 1].type)
                        for (int n = -1;n <= 1;n++) 
                        grid[i][j + n].match++;
            }
            

        //Moving animation
        isMoving = false;
        for (int i = 1;i <= 8;i++)
            for (int j = 1;j <= 8;j++)
            {
                piece& p = grid[i][j];
                int dx, dy;
                for (int n = 0;n < 4;n++)   // 4 - speed
                {
                    dx = p.x - p.c * ts;
                    dy = p.y - p.r* ts;
                    if (dx) p.x -= dx / abs(dx);
                    if (dy) p.y -= dy / abs(dy);
                }
                if (dx || dy) isMoving = 1;
            }

        //Deleting amimation
        if (!isMoving)
            for (int i = 1;i <= 8;i++)
                for (int j = 1;j <= 8;j++)
                    if (grid[i][j].match) 
                     if (grid[i][j].alpha > 10) 
                    { 
                    grid[i][j].alpha -= 10; 
                    isMoving = true;
                    }

        //To get score
        int score = 0;
        for (int i = 1;i <= 8;i++)
            for (int j = 1;j <= 8;j++)
                score += grid[i][j].match;
               

        //Second swap if no match
        if (isSwap && !isMoving)
        {
            if (!score) swap(grid[y0][x0], grid[y][x]); isSwap = 0;}

        //Update grid
        if (!isMoving)
        {
            for (int i = 8;i > 0;i--)
                for (int j = 1;j <= 8;j++)
                    if (grid[i][j].match)
                        for (int n = i;n > 5;n--)
                            if (!grid[n][j].match)
                             { 
                             swap(grid[n][j], grid[i][j]);  break;};

            for (int j = 1;j <= 8;j++)			//for free fall of tiles
                for (int i = 8, n = 0;i > 0;i--)
                    if (grid[i][j].match)
                    {
                        grid[i][j].type = rand() % 7;
                        grid[i][j].y = -ts * n++;
                        grid[i][j].match = 0;
                        grid[i][j].alpha = 255;
                    }
        }


	 sf::Time elapsed = clock.getElapsedTime();                     //timer
	 timer=elapsed.asSeconds();
       

        ////draw
        app.draw(background);
        
         string str;
		str = to_string(score);		//type casting
		Text text1(str, font);
		
		text1.setCharacterSize(40);
	
	text1.setFillColor(Color::White);
	
	text1.setStyle(Text::Bold);
	
	text1.setPosition(650.f, 30.f);
	
	 string str2;
        str2 = to_string(timer);
        Text text2(str2, font);
		
		text2.setCharacterSize(40);
	
	text2.setFillColor(Color::White);
	
	text2.setStyle(Text::Bold);
	
	text2.setPosition(530.f, 100.f);        


        for (int i = 1;i <= 8;i++)
            for (int j = 1;j <= 8;j++)
            {
                piece p = grid[i][j];
                animals.setTextureRect(IntRect(p.type * 49, 0, 49, 49));
                animals.setColor(Color(255, 255, 255, p.alpha));
                animals.setPosition(p.x, p.y);
                animals.move(offset.x - ts, offset.y - ts);
                app.draw(animals);
                
            }
            
               Event a;
		while(app.pollEvent(a))
		{
			switch(a.type)
			{
				case sf::Event::Closed:
				app.close();
				break;
				case Event::MouseButtonPressed:
				if(a.key.code == Mouse::Left)
				{
					sc -=1;
					cout<<sc<<std::endl;
				}
				if(sc<=0)
				{
					app.close();
				}
			}
		}
		

         
         app.draw(text); 
         app.draw(text1);
         app.draw(text2);
         ScoreBar.setSize(sf::Vector2f(sc*20, 20));
         app.draw(ScoreBar);
         app.display();
    }



     
	return 0;
}

