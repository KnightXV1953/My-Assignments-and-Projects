#include<SFML/Graphics.hpp>
#include<iostream>
int main()
{
	sf::Vector2i Screen(800, 600);
	sf::RenderWindow
	Window(sf::VideoMode(Screen.x,Screen.y),"ScoreBar");
	Window.setFramerateLimit(144);
	int sc=20;
	sf::RectangleShape ScoreBar;
	ScoreBar.setFillColor(sf::Color::Blue);
	ScoreBar.setOutlineThickness(2);
	ScoreBar.setOutlineColor(sf::Color::Red);
	ScoreBar.setPosition(200, 50);
	while (Window.isOpen())
	{
		sf::Event e;
		while(Window.pollEvent(e))
		{
			switch(e.type)
			{
				case sf::Event::Closed:
				Window.close();
				break;
				case sf::Event::KeyReleased:
				if(e.key.code == sf::Keyboard::A)
				{
					sc -=1;
					std::cout<<sc<<std::endl;
				}
				if(sc<=0)
				{
					Window.close();
				}
			}
		}
		ScoreBar.setSize(sf::Vector2f(sc*20, 20));
		Window.draw(ScoreBar);
		Window.display();
		Window.clear();
	}
return 0;
}
