#include <iostream>
using namespace std;

void samplechoice();
void task2();
void task3();
void task4();
void task7();
int main()
{
 samplechoice();
}
void samplechoice(){
int userchoice;
cout<<"which task you want to see"<<endl;
cin>>userchoice;
switch(userchoice)
{
case 2:
task2();
break;
case 3:
task3();
break;
case 4:
task4();
break;
case 7:
task7();
break;
}
}

void task2(){
   
int average, sum = 0 ;
int i ;
int number[5] ; 
for ( i = 1 ; i <= 5; i++ )

{
cout<<"enter the numbers";
cin>> number[i]; 
}
for ( i = 1 ; i <= 5 ; i++ )
sum = sum + number[i] ; 
average = sum / 5 ;
cout<<"average ="<<average ;
}
void task3(){}
void task4(){


    float arr[]={32.20,41.88,16.12,23.88,7.21};
    float sum=0;
    int size=sizeof(arr)/sizeof(int);
    for(int i=0; i<size; i++)
    {
        arr[i]=arr[i]/2;
        sum=sum+arr[i];
        cout<<arr[i];
        cout<<endl;
    }
    cout<<"the sum is"<<" "<<sum<<endl;

}
void task7()
{
    int arr[50];
    int j=25;
    int temp=0;
    int notosearch=0;
    for(int i=0; i<50; i++)
    {
        cin>>arr[i];
    }
    for(int i=0; i<25; i++)
    {
        temp=arr[j];
        arr[j]=arr[i];
        arr[i]=temp;
        j++;
    }
    cout<<"the inversed array is"<<endl;
    for(int i=0; i<50; i++)
    {
        cout<<arr[i];
        cout<<" ";
    }
    cout<<endl;
    cout<<"enter number to search"<<endl;
    cin>>notosearch;
    for(int i=0; i<50; i++)
    {
        if(notosearch=arr[i])
        {
            cout<<"no on index is"<<i<<endl;
        }
        
        }
}



