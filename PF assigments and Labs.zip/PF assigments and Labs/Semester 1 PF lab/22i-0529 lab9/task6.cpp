#include<iostream>
using namespace std;
float volumn(float r);
float v;
int main()


{
float r;
float volum;
const float pi = 3.1415;
cout<<"enter the radius"<<endl;
cin>>r;

volum=volumn(r);
cout<<volum;
return 0;
}




//define
float volumn(float r)
{
    float vol=0;
    vol=(4.0/3.0)*3.1415*(r*r*r);
    return vol;
}

