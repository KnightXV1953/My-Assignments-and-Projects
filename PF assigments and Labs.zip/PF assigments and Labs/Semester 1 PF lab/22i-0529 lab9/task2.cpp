#include<iostream>
#include<cstdlib>
#include<time.h>
using namespace std;
char game(char choice1 , char choice2); //prototype
int w1=0,w2=0,tie=0;
int main()
{
char choice1,choice2;
for(int i=1;i<4;i++)     //for loop 
{
cout<<"Round"<<i<<endl;
cout<<"Choose one of the following and press accordingly"<<endl;
cout<<"r for rock"<<endl;
cout<<"p for paper"<<endl;
cout<<"s for scissors"<<endl;
cin>>choice1;
srand(time(NULL));
choice2=(rand()%3)+1;    //use of srand function to pick numbers from 1 to 3

if (choice2==1)
{
choice2='r';
}
else if(choice2==2)
{
choice2='p';

}
else if(choice2==3)
{
choice2='s';
}
cout<<game(choice1,choice2)<<endl;

}

if(w1>w2 && w1>tie)
{
cout<<"user has won the tournment. Congrats!!!!"<<endl;
}
else if(w1<w2 && w2>tie)
{
cout<<"Computer has won the tournament"<<endl;
}
else
{
cout<<"Choose one of the following and press accordingly"<<endl;
cout<<"r for rock"<<endl;
cout<<"p for paper"<<endl;
cout<<"s for scissors"<<endl;
cin>>choice1;
cin>>choice2;
cout<<game(choice1,choice2)<<endl;
}

}

char game(char choice1,char choice2)   //Definetion
{
if(choice1=='r' && choice2=='p')
{
cout<<"User choice is"<<endl;
cout<<"Rock"<<endl;
cout<<"Computer choice is"<<endl;
cout<<"Paper"<<endl;
cout<<"Computer has won"<<endl;
w2++;
}
else if(choice1=='r' && choice2=='s')
{
cout<<"User choice is"<<endl;
cout<<"Rock"<<endl;
cout<<"Computer choice is"<<endl;
cout<<"Scissors"<<endl;
cout<<"User has won"<<endl;
w1++;
}
else if(choice1=='p' && choice2=='r')
{
cout<<"User choice is"<<endl;
cout<<"Paper"<<endl;
cout<<"Computer choice is"<<endl;
cout<<"Rock"<<endl;
cout<<"User has won"<<endl;
w1++;
}
else if(choice1=='p' && choice2=='s')
{
cout<<"User choice is"<<endl;

cout<<"Paper"<<endl;
cout<<"Computer choice is"<<endl;
cout<<"Scissors"<<endl;
cout<<"Computer has won"<<endl;
w2++;
}
else if(choice1=='s' && choice2=='p')
{
cout<<"User choice is"<<endl;
cout<<"Scissors"<<endl;
cout<<"Computer choice is"<<endl;
cout<<"Paper"<<endl;
cout<<"User has won"<<endl;
w1++;
}
else if(choice1=='s' && choice2=='r')
{
cout<<"User choice is"<<endl;
cout<<"Scissors"<<endl;
cout<<"Computer's choice is"<<endl;
cout<<"Rock"<<endl;
cout<<"Computer has won"<<endl;
w2++;
}
else if(choice1=='s' && choice2=='s')
{
cout<<"User choice is"<<endl;
cout<<"Scissors"<<endl;
cout<<"Computer's choice is"<<endl;
cout<<"Scissors"<<endl;
cout<<"Tie"<<endl;
tie++;

}
else if(choice1=='r' && choice2=='r')
{
cout<<"User choice is"<<endl;
cout<<"rock"<<endl;
cout<<"player two choice is"<<endl;
cout<<"rock"<<endl;
cout<<"Tie"<<endl;
tie++;
}
else if(choice1=='p' && choice2=='p')
{
cout<<"User choice is"<<endl;
cout<<"Paper"<<endl;
cout<<"Computer's choice is"<<endl;
cout<<"Paper"<<endl;
cout<<"Tie"<<endl;
tie++;
}
else
{
    cout<<"invalid input please enter 'r' , 'p' or 's' "<<endl;
}

cout<<"Scoreboard"<<endl;    //final scoreboard
cout<<"Total wins of User are:"<<w1<<endl;
cout<<"Total wins of Computer are :"<<w2<<endl;
cout<<"Ties happened are :"<<tie<<endl;
}
