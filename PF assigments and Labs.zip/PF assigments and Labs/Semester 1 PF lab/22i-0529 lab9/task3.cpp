#include <iostream>
using namespace std;
float sinx(float x, float n);

int main ()
{
float num,sin1x,result;
cout<<"enter value of sin"<<endl;
cin>>sin1x;
cout<<"enter the power"<<endl;
cin>>num;
result=sinx(sin1x, num);
cout<<"sin"<<sin1x<<" "<<result;
return 0;
}

float sinx(float x, float n)
{
float facto=1,power=1,add=0,sign=-1,series=0,value=0;
for(int i=1; i<=n; i=i+2)
{
for(int j=1; j<=i; j++)
{
facto=facto*j;
power=x*power;
}
sign=-1 * sign;
value=sign*(power/facto);
series=series+value;

}
return series;
}
