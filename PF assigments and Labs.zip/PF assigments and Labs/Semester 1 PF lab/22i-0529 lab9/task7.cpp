#include <iostream>
using namespace std;
//function decleration
int timeshundred(int num1);
int r;
int main()
{
int num1;
int product;
cout<<"enter the number  "<<endl;
cin>>num1;
product=timeshundred(num1);
cout<<product;
return 0;
}
//define
int timeshundred(int num1)
{
r=100*num1;
return r;
}
