#include <iostream>
using namespace std;
int x;
int triangle(int num);
int triangle(int num)
{
for(int row=1; row<=num; row++)
{
for(int column=1; column<=row; column++)
{
cout<<  " " << x;
x++;
}
cout<<endl;
}
return 0;
}
int main()
{
int num;
cin>>num;
triangle(num);
return 0;
}
