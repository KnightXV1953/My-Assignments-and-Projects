#include <iostream>
using namespace std;
int main()
{
cout<<"It was narrated from Umm Salaman that when the prophet (PBUH) performed the Subh (morning prayer), while He (PBUH) said the Salam, He (PBUH) would say:"<<endl;
cout<<"Allahumma inni as'aluka' ilman nafi'an wa rizqan tayyiban, wa 'amalan mutaqabbalan (O Allah, i ask You for beneficial knowledge, good provision and acceptable deeds).'-Sunan of Ibn Majah, Vol. 1, Book 5, Hadith 925"<<endl;
return 0;
}
