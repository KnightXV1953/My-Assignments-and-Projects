#include <iostream>
using namespace std;
int main()
{
int a=3;
cout<<"enter a number"<<endl;
cin>>a;
for(int i=1;i<13; i++)
{
cout<<a<<"*"<< i <<"=" << i*a<<endl;
}







return 0;
}
