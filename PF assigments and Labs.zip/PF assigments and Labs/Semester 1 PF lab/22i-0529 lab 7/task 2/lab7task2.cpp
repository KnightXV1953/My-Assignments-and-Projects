#include <iostream>
using namespace std;
int main()
{
int num=0;
int sum=0;
int average=0;
int num1=0;
cout<<"print sum of even number till"<<endl;
cin>>num;
for(int i=2;i<=500;i=++++i)
{
sum=sum+i;
num1=num1+1;
}
cout<<num<<endl;
average=sum/num1;
cout<<"sum of even number from 1 to 500 is"<<endl;
cout<<sum<<endl;
cout<<"aveage of even number between 1 to 500 is"<<endl;
cout<<average<<endl;







return 0;
}
