#include <iostream>
using namespace std;
int main()
{
cout<<"The prophet (SallAllah Alayhi WasSalam)said:"<<endl;
cout<<"\"Lying is wrong, except in three things: the lie of a man to his wife to make her content with him; a lie in war, for war is deception; or a lie to settle troubles between people.\""<<endl;
cout<<"[Ahmad,6.459.H]."<<endl;
cout<<"thanks!";
return 0;
}
