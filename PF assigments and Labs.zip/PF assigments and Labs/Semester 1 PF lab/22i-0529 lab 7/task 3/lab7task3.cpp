#include <iostream>
using namespace std;

int main() {

  int i, n;
  int x = true;

  cout << "Enter a positive integer: ";
  cin >> n;

  if (n == 0)
{
    x = false;
}

  for (i = 2; i <= n/2; ++i)
 {
    if (n % i == 0) {
      x = false;
      break;
 }
}

  if (x)
    cout << n << " is a prime number"<<endl;
  else
    cout << n << " is not a prime number"<<endl;

  return 0;
}                                                      
