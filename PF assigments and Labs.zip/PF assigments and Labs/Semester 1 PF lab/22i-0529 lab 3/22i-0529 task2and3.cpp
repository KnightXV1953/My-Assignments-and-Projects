#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
    cout<<"*       *"<<endl;
    cout<< setw(2) << "*" << setw(2) << "-" << setw(3) <<"*" <<endl;
    cout<< setw(2) << "*" << setw(2) <<"-" << setw(3) <<"*" <<endl;
    cout<< setw(1) <<"*"<< setw(7) << "*" <<endl;
return 0;
}
