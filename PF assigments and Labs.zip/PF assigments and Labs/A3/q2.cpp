#include <iostream>
#include <iomanip>
using namespace std;

int main()
{

float no_to_scale;
cout << " please enter the number you want pattern to be scaled by ";
cin >> no_to_scale;

for (float i = 0; i<13*no_to_scale ;i++)                 //outerloop for rows
{
    for (float j =0; j<3*no_to_scale && i!=2 ; j++)             //inner loop
    {
       cout << " ";
    }
    for (float k = 0; i ==2 && k <3*no_to_scale;k++)
    {
        cout << "_";
    }
    for (float a = 0; a < 11*no_to_scale;a++)
    {
        cout << "*";
    }
    if (no_to_scale==1.5)
    {
        cout << "*";
    }
    for ( float k = 0; i ==2 && k<3*no_to_scale ; k++)
    {
        cout << "_";
    }
    cout << endl;
}

for (float i = 0; i<13*no_to_scale ;i++)                    //outerloop 
{
    for (float j =0; j<3*no_to_scale ; j++)                 //print spaces
    {
       cout << " ";
    }
    for (float a = 0; a < 2*no_to_scale;a++)
    {
        cout << "*";
    }
    for (float k = 0; k < 1*no_to_scale ;k++)
    {
        cout << "|";
    }
    for (float b = 0; b < 5*no_to_scale ;b++)
    {
        cout << "*";
    }
     for (float k = 0; k < 1*no_to_scale ;k++)
    {
        cout << "|";
    }
     for (float b = 0; b < 2*no_to_scale ;b++)
    {
        cout << "*";
    }
    cout << endl;
}
for (float i = 0; i<13*no_to_scale ;i++)
{
    for (float j =0; j<1*no_to_scale ; j++)
    {
       cout << " ";
    }
    for (float c = 0; c<2*no_to_scale;c++)
    {
        cout << "|";
    }
    for (float a = 0; a < 2*no_to_scale;a++)
    {
        cout << "*";
    }
    for (float k = 0; k < 1*no_to_scale ;k++)
    {
        cout << "|";
    }
    for (float b = 0; b < 5*no_to_scale ;b++)
    {
        cout << "*";
    }
     for (float k = 0; k < 1*no_to_scale ;k++)
    {
        cout << "|";
    }
     for (float b = 0; b < 2*no_to_scale ;b++)
    {
        cout << "*";
    }
     for (float d = 0; d<2*no_to_scale;d++)
     {
         cout <<"|";
     }
    cout << endl;
}
for (float i =0; i<1*no_to_scale;i++)
{
    cout  <<" ";
}
for (float i =0; i<15*no_to_scale;i++)
{
    cout <<setw(1) << "-";
}

cout << endl;

for (float i = 0;i<3*no_to_scale;i++)    
{
    for(float e =0; e<2*no_to_scale;e++)
    {
        cout << " ";
    }
    for (float a =0; a<13*no_to_scale; a++)
    {
        cout << "^";
    }
    cout << endl;
}

return 0;
}
