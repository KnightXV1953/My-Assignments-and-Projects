#include <iostream>
#include <cmath>
using namespace std;

int main()
{
long int D_num=0;
long int num;
long int remain;
long int base=1;
long int binary=0;

long int binaryone;
long int H_num=0 ;
long int remain1;
long int i=1;

long int binary2;
long int O_num=0;
long int remain2;
long int j=1;

cout << "Enter a decimal number" ;
cin >> num ;
D_num=num ;


while(num>0)       //first we will convert it into binary just to make it easy
{
remain=num%2;
binary=binary+remain*base;
num=num/2;
base=base*10;
}


binaryone=binary;


while(binaryone!=0)        //here converted into hexadecimal
{
remain1=binaryone%10;
H_num=H_num+remain1*i;
i=i+2;
binaryone=binaryone/10;
}
cout << "The number given in Hexadecimal will be: " << H_num<< endl;


while(D_num!=0)               //and finally octal
{
remain2=D_num%8;
O_num=O_num+remain2*j;
j=j*10;
D_num=D_num/8;

}

cout << "The number given in Octal form will be : " << O_num<<endl;
return 0;
}

