#include<iostream>
#include<string.h>
using namespace std;
int main()
{
    string a;
    int x=0;
    int words=0;
    cout<<"enter the sentence"<<endl;
    getline(cin,a);
    for(int i=0;a[i]!=0;i++)  //to find words only
    {
        if(a[i]== ' ')
    {
        if(x!=0)
        {
            words++;
        }
        x=0;
        
    }
        else
        {
            
            x++;
            
        }
}
if(x!=0)
{
    words++;
}
cout<<"Total Words = " <<words;
return 0;
}



