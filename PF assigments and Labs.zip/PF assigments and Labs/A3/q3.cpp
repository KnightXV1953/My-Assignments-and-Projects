#include <iostream>

using namespace std;

int main()
{
    string name;
    int x;
    int price;
    int quantity;
    int total1=0,total2=0,total3=0,total4=0,total5=0,total6=0,total7=0,total8=0,total9=0,total10=0,total11=0,total12=0,total13=0,total14=0,total15=0,total16=0,total17=0,total18=0,total19=0,total20=0;
    int total;
    int grand_total;
    long int no;
    int Fries,burger,Chicken,juice,Shakes,Sandwiches,Chinese,Roll_Paratha,Biryani,Samosa_Chat,Soup,Fish,Shawarma,Daal,Sabzi,Malai_boti,karahi,mutton,Pizza,Loaded_fries;
    cout<<"Whats your name"<<endl;
    getline(cin,name);
    cout<<"whats your contact number"<<endl;
    cin>>no;
    cout<<endl;
    cout<<endl;
     cout<<"what you want to order?  Press 1 , 2 , 3 accordingly. Thanks"<<endl;
     
    
    for(int i=1; i<=6; i++)
    {
        cout<<"choose item"<<endl;
        cout<<"Menu include"<<endl;
        cout<<"___________________________________________________________________________________________________________________________________"<<endl;
        {
            cout<<" 1.Fries , 2.burgers , 3.Chicken , 4.Juices , 5.Shakes , 6.Sandwiches , 7.Chinese , 8.Roll Paratha , 9.Biryani , 10.Samosa Chat , 11.Soup , 12.Fish , 13.Shawarma , 14.Daal , 15.Sabzi , 16.Malai boti , 17.karahi , 18.mutton , 19.Pizza , 20.Loaded fries .  " <<endl;
        }
        cout<<"___________________________________________________________________________________________________________________________________"<<endl;
        cin>>x;
        switch(x)
       {
        case 1:
        cout<<"enter your quantity"<<endl;
        cin>>quantity;
        price=50;
        cout<<" you have ordered fries "<<endl;
        total1=quantity*price;
        cout<<" fries " << quantity << " " << total1 <<endl;
        cout<<endl;
        break;
        
        
        case 2:
        cout<<"enter your quantity"<<endl;
        cin>>quantity;
        price=100;
        cout<<" you have ordered burger "<<endl;
        total2=quantity*price;
        cout<<" burger " << quantity << " " << total2 <<endl;
        cout<<endl;
          break;
        
        
        case 3:
        cout<<"enter your quantity"<<endl;
        cin>>quantity;
        price=100;
        cout<<" you have ordered chicken "<<endl;
        total3=quantity*price;
         cout<<" chicken " << quantity << " " << total3 <<endl;
         cout<<endl;
           break;
         
         
         
        case 4:
        cout<<"enter your quantity"<<endl;
        cin>>quantity;
        price=50;
        cout<<" you have ordered juice "<<endl;
        total4=quantity*price;
         cout<<" juice " << quantity << " " << total4 <<endl;
         cout<<endl;
           break;
         
         
         
        case 5:
        cout<<"enter your quantity"<<endl;
        cin>>quantity;
        price=60;
         cout<<" you have ordered shakes "<<endl; 
         total5=quantity*price;
          cout<<" shakes " << quantity << " " << total5 <<endl;
          cout<<endl;
            break;
          
          
          
          case 6:
          cout<<"enter your quantity"<<endl;
        cin>>quantity;
        price=100;
         cout<<" you have ordered Sandwiches "<<endl; 
         total6=quantity*price;
          cout<<" Sandwiches " << quantity << " " << total6 <<endl;
          cout<<endl;
            break;
          
          
          
          case 7:
          cout<<"enter your quantity"<<endl;
        cin>>quantity;
        price=100;
         cout<<" you have ordered Chinese "<<endl; 
         total7=quantity*price;
          cout<<" Chinese " << quantity << " " << total7 <<endl;
          cout<<endl;
            break;
          
          
          
          case 8:
          cout<<"enter your quantity"<<endl;
        cin>>quantity;
        price=100;
         cout<<" you have ordered Roll paratha "<<endl; 
         total8=quantity*price;
          cout<<" Roll_Paratha" << quantity << " " << total8 <<endl;
          cout<<endl;
            break;
          
          
          case 9:
          cout<<"enter your quantity"<<endl;
        cin>>quantity;
        price=100;
         cout<<" you have ordered Biryani "<<endl; 
         total9=quantity*price;
          cout<<" Biryani " << quantity << " " << total9 <<endl;
          cout<<endl;
            break;
          
          
          
          case 10:
          cout<<"enter your quantity"<<endl;
        cin>>quantity;
        price=100;
         cout<<" you have ordered Samosa chat "<<endl; 
         total10=quantity*price;
          cout<<" Samosa chat " << quantity << " " << total10 <<endl;
          cout<<endl;
            break;
          
          
          
          case 11:
          cout<<"enter your quantity"<<endl;
        cin>>quantity;
        price=50;
         cout<<" you have ordered soup "<<endl; 
         total11=quantity*price;
          cout<<" soup " << quantity << " " << total11 <<endl;
          cout<<endl;
            break;
          
          
          
          case 12:
          cout<<"enter your quantity"<<endl;
        cin>>quantity;
        price=100;
         cout<<" you have ordered fish "<<endl; 
         total12=quantity*price;
          cout<<" fish " << quantity << " " << total12 <<endl;
          cout<<endl;
            break;
          
          
          
          
          case 13:
          cout<<"enter your quantity"<<endl;
        cin>>quantity;
        price=100;
         cout<<" you have ordered shawarma "<<endl; 
         total13=quantity*price;
          cout<<" shawarma " << quantity << " " << total13 <<endl;
          cout<<endl;
            break;
          
          
          
          
          case 14:
          cout<<"enter your quantity"<<endl;
        cin>>quantity;
        price=100;
         cout<<" you have ordered daal "<<endl; 
         total14=quantity*price;
          cout<<" daal " << quantity << " " << total14 <<endl;
          cout<<endl;
            break;
          
          
          
          
          case 15:
          cout<<"enter your quantity"<<endl;
        cin>>quantity;
        price=100;
         cout<<" you have ordered sabzi "<<endl; 
         total15=quantity*price;
          cout<<" sabzi " << quantity << " " << total15 <<endl;
          cout<<endl;
            break;
          
          
          
          case 16:
          cout<<"enter your quantity"<<endl;
        cin>>quantity;
        price=150;
         cout<<" you have ordered malai boti "<<endl; 
         total16=quantity*price;
          cout<<" Malai boti " << quantity << " " << total16 <<endl;
          cout<<endl;
            break;
          
          
          
          case 17:
          cout<<"enter your quantity"<<endl;
        cin>>quantity;
        price=200;
         cout<<" you have ordered karahi "<<endl; 
         total17=quantity*price;
          cout<<" karahi " << quantity << " " << total17 <<endl;
          cout<<endl;
            break;
          
          
          
          case 18:
          cout<<"enter your quantity"<<endl;
        cin>>quantity;
        price=300;
         cout<<" you have ordered mutton "<<endl;
         total18=quantity*price;
          cout<<" mutton " << quantity << " " << total18 <<endl;
          cout<<endl;
            break;
          
          
          
          case 19:
          cout<<"enter your quantity"<<endl;
        cin>>quantity;
        price=350;
         cout<<" you have ordered pizza "<<endl; 
         total19=quantity*price;
          cout<<" pizza " << quantity << " " << total19 <<endl;
          cout<<endl;
            break;
          
          
          
          case 20:
          cout<<"enter your quantity"<<endl;
        cin>>quantity;
        price=100;
         cout<<" you have ordered loaded fries "<<endl; 
         total20=quantity*price;
          cout<<" loaded fries " << quantity << " " << total20 <<endl;
          cout<<endl;
            break;
            
            
            default:
            cout<<"invalid input"<<endl;
            
    }
    cout<<"Thanks for order"<<endl;
    }
    
    cout<<"BILL"<<endl;
    
    cout<<"---------------------------------------"<<endl;
    cout<<name<<endl;
    
    cout<<no<<endl;
    cout<<endl;
    total=total1+total2+total3+total4+total5+total6+total7+total8+total9+total10+total11+total12+total13+total14+total15+total16+total17+total18+total19+total20;
    cout<<"your total bill of all items is"<<endl;
    cout<<total;
    cout<<endl;
    cout<<"your total bill after \"GDP\" TAX is"<<endl;
    grand_total=total*1.2;
    cout<<endl;
    cout<<grand_total;
    cout<<endl;
    cout<<"Thanks for Ordering. Enjoy your meal"<<endl;
   
    cout<<"_______________________________________"<<endl;

    return 0;
}





