#include <iostream>
using namespace std;
int main()
{


int x;
char x1;
char x2;
char x3;
char x4;
char x5;
char x6;


int y1;                 //declaring variables to store characters in it
int y2;
int y3;
int y4;
int y5;
int y6;



int r1, r2, r3,r4;


cout << "How many characters do you want to enter?"<<endl;
cin >> x;
cout << "Enter your character"<<endl;

if (x == 1)
{
    cin >> x1;
    y1 = int(x1);

    cin>>r1>>r2>>r3>>r4;

    cout<<y1<<" "<<r1;

}
else if (x==2)
{
    cin >> x1;
    cin >> x2;

    y1 = int(x1);
    y2 = int(x2);

    cout << "Enter your roll number: "<< endl;
    cin >>r1>>r2>>r3>>r4;

    cout <<y1<<" "<<r1<<" "<<y2<<" "<<r2;

}
else if (x==3)
{
    cin >> x1;
    cin >> x2;
    cin >> x3;

    y1 = int(x1);
    y2 = int(x2);
    y3 = int(x3);


    cout << "Enter your roll number: "<< endl;
    cin>>r1>>r2>>r3>>r4;

    cout <<y1<<" "<<r1<<" "<<y2<<" "<<r2<<" "<<y3<<" "<<r3;
}
else if (x==4)
{
    cin >> x1;
    cin >> x2;
    cin >> x3;
    cin >> x4;

    y1 = int(x1);
    y2 = int(x2);
    y3 = int(x3);
    y4 = int(x4);

    cout << "Enter your roll number: "<< endl;
    cin>>r1>>r2>>r3>>r4;

    cout <<y1<<" "<<r1<<" "<<y2<<" "<<r2<<" "<<y3<<" "<<r3<<" "<<y4<<" "<< r4;
}
else if (x==5)
{
    cin >> x1;
    cin >> x2;
    cin >> x3;
    cin >> x4;
    cin >> x5;

    y1 = int(x1);
    y2 = int(x2);
    y3 = int(x3);
    y4 = int(x4);
    y5 = int(x5);

    cout << "Enter your roll number: "<< endl;
    cin>>r1>>r2>>r3>>r4;

    cout <<y1<<" "<<r1<<" "<<y2<<" "<<r2<<" "<<y3<<" "<<r3<<" "<<y4<<" "<< r4 <<" "<< y5<<" "<<"1";




}
else if (x==6)
{
    cin >> x1;
    cin >> x2;
    cin >> x3;
    cin >> x4;
    cin >> x5;
    cin >> x6;

    y1 = int(x1);
    y2 = int(x2);
    y3 = int(x3);
    y4 = int(x4);
    y5 = int(x5);
    y6 = int(x6);

    cout << "Enter your roll number: "<< endl;
    cin >> r1 >> r2 >> r3 >> r4;

    cout <<y1<<" "<<r1<<" "<<y2<<" "<<r2<<" "<<y3<<" "<<r3<<" "<<y4<<" "<< r4 <<" "<< y5 <<" "<< "1" << " "<< y6 ;

}
else
cout<<"invalid input"<<endl;
return 0;
}


