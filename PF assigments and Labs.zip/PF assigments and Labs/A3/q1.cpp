#include <iostream>
using namespace std;
int main()
{
bool a=0,b=0,c=0,d=0;
int x=0, no1=0 , no2=0;
cout<<"enter the number"<<endl;
cin>>x;
if(x==0)

{
no1=0000;

cout<<no1;
}
else if(x==1)
{
no1=0001;

cout<<no1;
}
else if(x==2)
{
no1=0010;

cout<<no1;
}
else if(x==3)
{
no1=0011;

cout<<no1;
}
else if(x==4)
{
no1=0100;

cout<<no1;
}
else if(x==5)
{
no1=0101;

cout<<no1;
}
else if(x==6)
{
no1=0110;

cout<<no1;
}
else if(x==7)
{
no1=0111;

cout<<no1;
}
else if(x==8)
{
no1=1000;

cout<<no1;
}
else if(x==9)
{
no1=1001;

cout<<no1;
}
cout<<endl;

switch(no1)
{
case(0000):
{
a=false;
b=false;
c=false;
d=false;

cout<<a<<b<<c<<d;
break;
}



case(0001):
{
a=false;
b=false;
c=false;
d=true;

cout<<a<<b<<c<<d;
break;
}



case(0010):
{
a=false;
b=false;
c=true;
d=false;

cout<<a<<b<<c<<d;
break;
}




case(0011):
{
a=false;
b=false;
c=true;
d=true;

cout<<a<<b<<c<<d;
break;
}




case(0100):
{
a=false;
b=true;
c=false;
d=false;

cout<<a<<b<<c<<d;
break;
}





case(0101):
{
a=false;
b=true;
c=false;
d=true;

cout<<a<<b<<c<<d;
break;
}





case(0110):
{
a=false;
b=true;
c=true;
d=false;

cout<<a<<b<<c<<d;
break;
}




case(0111):
{
a=false;
b=true;
c=true;
d=true;

cout<<a<<b<<c<<d;
break;
}




case(1000):
{
a=true;
b=false;
c=false;
d=false;

cout<<a<<b<<c<<d;
break;
}


case(1001):
{
a=true;
b=false;
c=false;
d=true;



cout<<a<<b<<c<<d;
break;
}
}




return 0;
}


