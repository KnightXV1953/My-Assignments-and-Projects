#include <iostream>
using namespace std;

int main ()
{
	int nodiamonds, greatestno = 0;
	
	cout << "Enter number of diamonds you would like to print out: ";
	cin >> nodiamonds;
	
	cout << "Enter the greatest number you want in diamond to be: ";
	cin >> greatestno;
	if(nodiamonds>=1)
	{
	
	for (int i = 1 ;i <= greatestno ;  i++)
	{
	
		for (int j = 1 ;  j <= nodiamonds ;  j++)
		{
			int k;
			for (k = 1 ;  k <= greatestno - i ;  k++)
			{
				cout << " ";
			}
			
			int x = i;
			for (; k <= greatestno ; k++)
			{
				cout << x--;
			}
		
			x = 1;
			for (; k <= greatestno + i ; k++)
			{
				cout << x++;
			}
			
			for (k = 1 ; k <= greatestno - i ; k++)
			{
				cout << " ";
			}
			
		}
		
		cout << endl;
	}
		
	for (int i=greatestno - 1 ; i >= 1 ; i--)
	{
	
		for (int j = 1 ; j <= nodiamonds ; j++)
		{
			int k;
			for (k = 1 ; k <= greatestno - i ; k++)
			{
				cout << " ";
			}
			
			int x = i;
			for (; k <= greatestno; k++)
			{
				cout << x--;
			}
		
			x = 1;
			for (; k <= greatestno + i ; k++)
			{
				cout << x++;
			}
			
			for (k = 1 ; k <= greatestno - i ; k++)
			{
				cout << " ";
			}
			
		}
			
		cout << endl;
	}
	}
	else
	cout<<"you need atleast 1 diamond to print out"<<endl;
	
	return 0;
}

